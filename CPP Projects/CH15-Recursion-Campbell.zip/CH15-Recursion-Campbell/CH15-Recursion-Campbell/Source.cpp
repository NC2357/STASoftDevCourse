//Nolan Campbell 17122020
//CH 15 Recursion Vs. Iteration project
//First challenge: Iterative solution to finding factorial of user input integer
//Second challenge: Simulate Towe of Hanoi with single-digit disks amounts
//Third challenge: Calculate the Fibonacci sequence from a starting point (Two integers) to the nth one in it's series and print it

#include <iostream>

using namespace std;

int factR(int num); //Recursive function to calculate factorial
void moveDisks(int disks, int sp1, int sp3, int sp2, int &moves);//Recursive function to simulate Towers of Hanoi
int fibo(int a, int b, int n);//Recursive function to find (n)th fibonnaci sequence number based on two consecutive inputs


int main() {

	int num; //Integer used as parameter and input for challenges
	int factorial;//Will hold the result of the first challenge
	int moves = 0;//Keep track of how many moves in Towers of Hanoi
	int a, b, n; //Integers used to take input to Fibonacci challenge

	cout << "This program will ask you to enter an integer, then will display the factorial." << endl;
	cout << "Please enter an integer your want to find the factorial for: ";
	cin >> num; //Number the user wants to find the factorial for

	//Recursive method of factorials
	cout << "The calculation used to determine the factorial of " << num << " is: " << endl;
	cout << "(";
	factorial = factR(num);//Function call here so that the calculation sequence is printed neatly
	cout << "\b)" << endl;
	cout << "The factorial of " << num << " using recursion is " << factorial << endl << endl;

	//This section will emulate Towers of Hanoi
	cout << "This section will emulate Towers of Hanoi, asking you for the number of disks to be moved." << endl;
	cout << "Enter number of disks: ";
	cin >> num; //Number of disks to be used in second challenge

	//Run moveDisks if num is in bounds.
	if (num < 1 || num > 9)
		cout << "Invalid input, moving to next challenge" << endl << endl;
	else{
		moveDisks(num, 1, 3, 2, moves); //Call to function to simulate towers of hanoi
		cout << "This Tower of Hanoi puzzle took " << moves << " moves" << endl << endl;
	}

	//This section will calculate the Fibonacci sequence from a starting point (Two integers) to the nth one in it's series and print it.
	cout << "The program will no calcuate the nth member in a Fibonacci sequence based on your parameters." << endl << endl;
	cout << "Please enter two consecutive, positive integers," << endl;
	cout << "seperated by a space to use as the starting point: ";
	cin >> a >> b;
	cout << endl;
	cout << "Now enter the desired nth number of the series: ";
	cin >> n;
	cout << endl;
	
	//The function call fibo in this cout increments n by one because based upon the sequence and various calculators, the first starting digit does not count
	//towards the number in the series, so (a) effectivley has the position of zero, and to counteract this, n must be incremented
	cout << "The result of the Fibonnaci sequence starting at " << a << " and " << b << " and going to number " << n << " in the series is " << fibo(a, b, n+1);
	
	cout << endl << endl;
	system("PAUSE");
	return 0;
}

//Recursive function to calculate factorial
int factR(int num) {
	if (num == 0) { //Base case: When the function reaches it's "end" it will trigger this, return 1 and cascade the value back to the top
		return 1;
	}
	else { //Activates if there are more number to be calculated
		cout << num << "*"; //Prints the current number used in calculation with a * to show multiplication
		return num * factR(num - 1); //Recursive call: multiplies num by the result of factR(num-1) 
		//which is what triggers the recursive effect of cascading to the base case and, and then returning to the "surface" 
		//call while calulating the factorial
	}
}

//Recursive function to simulate Towers of Hanoi
void moveDisks(int disks, int sp1, int sp3, int sp2, int &moves) {
	if (disks > 0) { //As long as there are disks left to be moved, do the follwing:
		moveDisks(disks - 1, sp1, sp2, sp3, moves); //Move disks -1 from sp1 to sp3 and so forth causing recursive effect
		cout << "Move disk " << disks << " from " << sp1 << " to " << sp3 << endl; //Print the move
		moves++; //Add to the move count
		moveDisks(disks - 1, sp2, sp3, sp1, moves);  //Move disks -1 from sp2 to sp1 and so forth, causing recursive effect
	} //Making it past this if-statements causes the returning effect back to it's caller
}

int fibo(int a, int b, int n) {
	//Base cases: Once reached will cause the actual calculation of the Fibonacci number through returns
	//Works because the recursion calls down to either n == 1 or 2, and is able to return opposing values so they can be properly added
	if (n == 2) { 
		return b;
	}
	if (n == 1) {
		return a;
	}
	else {
		return fibo(a, b, n - 1) + fibo(a, b, n - 2); //Formula used to call down to the starting point of Fibonacci calculations
	}
}