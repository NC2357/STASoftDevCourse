#include "candidateType.h"
#include <string>
#include <iostream>
#include <iomanip>

using namespace std;

int candidateType::totalVotes = 0;

//Initializes object
candidateType::candidateType(string name, string party, int votes) {
	//Variable Initialization
	this->name = name;
	this->party = party;
	this->votes = votes;
	totalVotes += votes;
}

//Initializes object
candidateType::candidateType() {
	//Variable Initialization
	name = "No Name";
	party = "No Party";
	votes = 0;
}

//Calulates the percentage of votes the candidate got
double candidateType::votePercent() {
	return (votes / (double)totalVotes)*100; //Calculate vote percent
}

//Return the total votes amongs all candidates
int candidateType::getTotalVotes() {
	return totalVotes;
}

//Returns name of candidate
string candidateType::getName() {
	return name;
}

//Prints the candidate information in a neat row
void candidateType::print() {
	//Prints information in a neat row.
	cout << left << setw(24) << name << left << setw(24) << party << right << 
		setw(14) << votes << right << setw(20) << votePercent() << endl;
}