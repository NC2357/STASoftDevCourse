#ifndef CANDIDATEYPE_H
#define CANDIDATETYPE_H

#include <string>

using namespace std;

class candidateType {
public:
	candidateType(string, string , int);
	//Initializes object
	//Pre: Call in other function and three parameters (name, party, votes)
	//Post: A candidate object

	candidateType();
	//Initializes object
	//Pre: Call in other function
	//Post: A candidate object

	double votePercent();
	//Calulates the percentage of votes the candidate got
	//Pre: Object must exist.
	//Post: returns double with vote percent

	int getTotalVotes();
	//Returns the total votes
	//Pre: Object exists and function is called
	//Post: Returns totalVotes as an int

	string getName();
	//Returns name of candidate
	//Pre: Object must exist and function is called
	//Post: Returns string of winners name

	void print();
	//Prints the candidate information in a neat row
	//Pre: Must be called
	//Post: Print to standard output

private:
	string name, party; //Name and party of candidate
	int votes; //Number of votes a candidate got
	static int totalVotes; //Keeps track of total votes to avoid voter fraud and calculate voter percent
};
#endif // !CANDIDATEYPE_H
