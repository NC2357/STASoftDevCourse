//Nolan Campbell 04122020
//Chapter 12 Assignment - Election Results OYO Project
//This program will prompt the user to enter between 3 and 5 candidates for the Murphyville election
//It will then output each candidates info, declare the winner, and calculate percentage of votes

#include "candidateType.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <cassert>

using namespace std;

const int MAX_VOTES = 999;

void createCandidates(candidateType*& candidateArray, int& arraySize); //Creates the candidate objects
void print(candidateType*& candidateArray, int& arraySize); //Prints candidate data
bool hasVoterFraud(candidateType candidate); //Determines if there is voter fraud, only needs one candidate as totalVotes is static
string findWinner(candidateType* &candidateArray, int &arraySize); //Determines winner of the election
int findSize(); //Dertermines size of candidateArray

int main() {
	//Variables
	int arraySize; //arraySize = size of dynamic array
	string winner = " "; //winner will hold the name of the winner

	//////Intro
	cout << "This program will intake candidates for the Murphyville Mayor election, and total their votes to determine a winner." << endl;
	cout << "It will also print each candidate along with their party, number of votes, and vote percent." << endl << endl;

	arraySize = findSize(); //Determine size of object
	candidateType *candidateArray = new candidateType[arraySize]; //Pointer used to hold dynamic array

	//////Create candidate objects
	createCandidates(candidateArray, arraySize);

	//////Determine voter fraud, Kill program is found
	if (!(hasVoterFraud(candidateArray[0]))) {
		cout << endl << endl << "Voter Fraud Detected, Program Terminating, Election Suspended";
		assert(false);
	}

	//////Print data
	print(candidateArray, arraySize);

	//////Determine winner
	winner = findWinner(candidateArray, arraySize);
	cout << endl << "The winner of the Murphville Mayor Election is " << winner;

	//Cleanup
	delete [] candidateArray;
	cout << endl << endl;
	system("PAUSE");
	return 0;
}

//Creates the candidate objects
void createCandidates(candidateType* &candidateArray, int& arraySize) {
	int votePerCandidate; //votePerCandidate = the number of votes a candidate got.
	string name, party; //Name and party of candidate

	//////Object creation
	for (int i = 0; i < arraySize; i++) {
		//When calling getline() after cin >>, a newline is left in the buffer so newline retrieve it. This fixes the issue
		cin.ignore(); 

		cout << "Enter the name for candidate " << i + 1 << ": " << endl;
		getline(cin, name);
		cout << endl;

		cout << "Enter the party for candidate " << i + 1 << ": " << endl;
		getline(cin, party);
		cout << endl;

		cout << "Enter the number of votes for candidate " << i + 1 << ": ";
		cin >> votePerCandidate;
		cout << endl;

		candidateArray[i] = candidateType(name, party, votePerCandidate); //Construct the object
	}
}

//Prints candidate data
void print(candidateType*& candidateArray, int& arraySize) {
	//Prints a banner
	cout << setw(35) << " " << setfill('-') << setw(19) << " " << endl;
	cout << setfill(' ') << setw(35) << " " << "| Candidate Data |" << endl;
	cout << setfill(' ') << setw(35) << " " << setfill('-') << setw(19) << " " << endl << setfill(' ');

	//Prints category
	cout << fixed << showpoint << setprecision(1);
	cout << left << setw(24) << "Candidate" << left << setw(24) << "Party" << right <<
		setw(14) << "Votes Received" << right << setw(20) << "% of Total Votes" << endl;

	//Prints object data
	for (int i = 0; i < arraySize; i++) {
		candidateArray[i].print();
	}
}


//Determines if there is voter fraud, only needs one candidate as total votes is static
bool hasVoterFraud(candidateType candidate) {
	return candidate.getTotalVotes() <= MAX_VOTES;
}

//Determines winner of the election
string findWinner(candidateType* &candidateArray, int &arraySize) { //Determines winner of the election
	double winningPercent = 0.0;
	string winner; //Keeps track of the name of the current winner
	//Finds if there is a tie, and determines winner if there is not one
	for (int i = 0; i < arraySize; i++) {

		//Decides if there is a new running winner
		if (winningPercent < candidateArray[i].votePercent()) {
			winningPercent = candidateArray[i].votePercent();
			winner = candidateArray[i].getName();
		}

		//Checks for tie
		for (int j = i+1; j < arraySize; j++) {
			if (candidateArray[i].votePercent() == candidateArray[j].votePercent() && winningPercent == candidateArray[i].votePercent())
				winner = "It's a Tie!! A Vote Recount is needed";
		}
	}
	return winner;
}

//Dertermines size of candidateArray
int findSize() {
	int arraySize;
	do {
		cout << "Enter the number of candidates in the Murphyville Mayor election(3-5): ";
		cin >> arraySize;
		cout << endl;

		if (!(arraySize >= 3 && arraySize <= 5)) //Ensure valid input
			cout << "Invalid Input, try again." << endl << endl;
	} while (!(arraySize >= 3 && arraySize <= 5)); //Keeps it in a loop until valid input entered
	return arraySize;
}
