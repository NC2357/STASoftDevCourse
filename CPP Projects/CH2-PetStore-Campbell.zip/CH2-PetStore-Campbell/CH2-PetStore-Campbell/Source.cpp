//Nolan Campbell 091620
//Chapter 2 Pet Store Project
//This program will allow the user to purchase six different animals in any reasonable quantity
//and will calculate the total price for them.

#include "Animal.h"
#include <iostream>
#include <iomanip>
#include <list>

using namespace std;

int main() {

	//setup

	const double SHIPPINGFEE = 50.00; //The shipping fee on each animal purchased

	double grandTotal = 0.00; //The end total of all the animals purchased plus the shippingFee

	char confirmation; //char used to confirm purchase

	cout << setprecision(10); //Sets the precision of the output for digits to 10 because the default of 6 is too short

	//Creates a list of animals which represent the animals in the pet store
	list<Animal> listOfAnimals = {
		Animal("Zebra", "Horse but with stripes", 7900.43),
		Animal("Lion", "Horse but with teeth", 1230.12),
		Animal("Gecko", "Horse but with weird eyse", 55.50),
		Animal("Parrot", "Horse but with speech", 1000.00),
		Animal("Alligator", "Horse but with water powers", 890.89),
		Animal("Horse", "Horse but with horse", 99999.99),
	};

	//Intro
	cout << "Welcome to Special Horses! \nWe have horses but better" << endl << endl;

	//input

	//Creates an iterator to iterate through animals in a loop
	list<Animal>::iterator it;

	for (it = listOfAnimals.begin(); it != listOfAnimals.end(); it++) {
		it->displayAnimalInfo(); //Displays the name, description and price of an animal

		int numPurchasedNow; //Number of a type of animal the user inputed to purchase

		//Allows the user to purchase an animal
		cout << "How many would you like to purchase(no negative numbers): ";
		cin >> numPurchasedNow;
		cout << endl;

		it->setNumPurchased(numPurchasedNow); //Sets the Animal object's variavle numPurchase to numPurchaseNow

		//Tells the user how many of an animal they purchased, and the total price.
		cout << "You purchased " << it->getNumPurchased() << " of the animal wich will cost a total of " << it->getTotalPrice() << "$" << endl << endl; 
	}

	//Total cost of all animals plus shipping calculation
	for (it = listOfAnimals.begin(); it != listOfAnimals.end(); it++) {
		//Will get the number of times an animal was purchased(numPurchased) multiply it by the shipping fee to get the total shipping fee for an animal.
		//getTotalPrice() will then be used to receive the total cost of thr purchase excluding the shipping. 
		//The shipping is then added to this cost and added to the grandTotal. The result will be the total cost of all purchased animals with the shipping fee.
		grandTotal += (double)it->getNumPurchased() * SHIPPINGFEE;
		grandTotal += it->getTotalPrice();
	}

	//Results and confirmation of purchase
	cout << "The grand total for all the animals including shipping is " << grandTotal << "$" << endl;
	cout << "Press any character and hit enter to confirm the purchase: ";
	cin >> confirmation;
	cout << endl << "Purchase confirmed, thank you." << endl << endl;

	system("PAUSE");
	return 0;
}