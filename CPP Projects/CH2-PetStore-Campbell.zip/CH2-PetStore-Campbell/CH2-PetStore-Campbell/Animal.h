#pragma once
#include <iostream>
using namespace std;

//Header file for class Animal. Animal will be used to store and manipulate data regarding each animal in the pet store.
class Animal {
public:
	Animal(string name, string description, double price);
	
	int getNumPurchased();
	void setNumPurchased(int numPurchased);
	double getTotalPrice();

	void displayAnimalInfo();

private:
	string name, description; //name is the name of the animal, description is the description of the animal
	const double PRICE; //price of a single animal
	int numPurchased; //The amount that one animal was purchased

};