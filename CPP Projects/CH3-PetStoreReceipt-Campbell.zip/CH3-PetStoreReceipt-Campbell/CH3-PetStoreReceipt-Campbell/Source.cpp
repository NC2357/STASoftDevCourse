//Nolan Campbell 092420
//Chapter 3 Pet Store Project With Receipt
//This program will allow the user to purchase six different animals in any reasonable quantity
//and will calculate the total price for them. It will then display a receipt with all of the information about the animals they purchased
//And what the user entered

#include "Animal.h"
#include <iostream>
#include <iomanip>
#include <list>

using namespace std;

double totalShipping(list<Animal> listOfAnimals, const double SHIPPINGFEE) {
	list<Animal>::iterator it;
	double totalShipping = 0;

	for (it = listOfAnimals.begin(); it != listOfAnimals.end(); it++) {
		//Will get the number of times an animal was purchased(numPurchased) and multiply it 
		//by the shipping fee to get the total shipping fee for an animal.
		totalShipping += (double)it->getNumPurchased() * SHIPPINGFEE;
	}
	return totalShipping;
}

double totalPurchase(list<Animal> listOfAnimals) {
	list<Animal>::iterator it;
	double totalPurchase = 0;

	for (it = listOfAnimals.begin(); it != listOfAnimals.end(); it++) {
		//getTotalPrice() will then be used to receive the total cost of the purchase excluding shipping. 
		totalPurchase += it->getTotalPrice();
	}
	return totalPurchase;
}

double grandTotal(list<Animal> listOfAnimals, const double SHIPPINGFEE) {
	//Adds total purchase and shipping to get grand total of order
	return totalPurchase(listOfAnimals) + totalShipping(listOfAnimals, SHIPPINGFEE);
}

void genReceipt(list<Animal> listOfAnimals, string lastName, string date, const string STORENAME, const double SHIPPINGFEE) {
	const int SCREENWIDTH = 80;
	list<Animal>::iterator it;

	//Receipt intro

	cout << setw(SCREENWIDTH) << setfill('_') << "" << endl << endl; // Prints an 80 character long stream of underscores
	cout << setw((SCREENWIDTH/2) + (STORENAME.length()/2.0)) << setfill(' ') << STORENAME << endl; //Prints and centers STORENAME
	cout << setw(SCREENWIDTH/2 + 6) << "SALES TICKET" << endl << endl; //Prints "SALES TICKET" centered

	//Customer and date information

	//Prints the customer size on the left and date on the right. 
	//The spacing in the middle is calulated by subtracting the length 
	//of "CUSTOMERNAME", maximum length of the date, and length of the lastName
	//This allow for constant and appropiate spacing between the name and date reglardless of the length of the user's last name
	cout << "CUSTOMER NAME: " << lastName << setw(SCREENWIDTH - 25 - lastName.length()) << right << "DATE: " << setw(10) << date << endl;

	//Purchase table

	cout << setw(SCREENWIDTH) << setfill('_') << "" << endl; // Prints an 80 character long stream of underscores
	//Prints out the name of each column appropriatley spaced. 
	//Spacing calculated by deciding what I want the total character count of 
	//each section I want and subtracting/adding appropiatley to account for category labels.
	cout << setfill(' ') << "| Quantity |" << setw(29) << "ITEM DESCRIPTION" << setw(27) << "| PRICE EACH |" << setw(8) << "TOTAL" << setw(4) << right << "|" << endl;
	cout << setw(SCREENWIDTH) << setfill('_') << "" << endl; // Prints an 80 character long stream of underscores

	//Prints each animal and it's according information
	for (it = listOfAnimals.begin(); it != listOfAnimals.end(); it++) {
		cout << setfill(' ') << "| " << left << setw(8) << it->getNumPurchased() << " | " << setw(40) << it->getReceiptDescrip() << " |$ "
			<< setw(9) << right << it->getPrice() << " |$" << setw(10) << it->getTotalPrice() << "|" << endl;
		cout << "|" << setw(11) << "|" << setw(43) << "|" << setw(13) << "|" << setw(12) << "|" << endl; //Prints an empty row
	}
	cout << setw(SCREENWIDTH) << setfill('_') << "" << endl; // Prints an 80 character long stream of underscores

	cout << setfill(' ') << setw(12) << "" << left << "TOTAL PURCHASE" << setw(43) << "" << "$" 
		<< setw(10) << right << totalPurchase(listOfAnimals) << endl;

	cout << setfill(' ') << setw(12) << "" << left << "SHIPPING" << setw(50) << "" 
		<< setw(10) << right << totalShipping(listOfAnimals, SHIPPINGFEE) << endl;

	cout << setfill(' ') << setw(SCREENWIDTH - 10) << "" << setfill('_') << setw(10) << "" << endl; //prints 10 underscores on the far right
	
	cout << setfill(' ') << setw(12) << "" << left << "GRAND TOTAL" << setw(46) << "" 
		<< "$" << setw(10) << right << grandTotal(listOfAnimals, SHIPPINGFEE) << endl;

	cout << endl << endl << setfill(' ');

	cout << setw((SCREENWIDTH / 2) + ((STORENAME.length() + 26.0) / 2.0)) << "THANK YOU FOR SHOPPING AT " + STORENAME << endl;
	cout << setw(SCREENWIDTH / 2 + 11) << "Please come again soon!";
	cout << endl;
}

int main() {

	//setup

	const double SHIPPINGFEE = 50.00; //The shipping fee on each animal purchased

	char confirmation; //char used to confirm purchase

	string lastName; //To hold last name of customer
	string date; //To store current date according to user
	const string STORENAME = "Special Horses"; //The name of the store
	const string STOREDESCRIPTION = "We have horses but better!"; //Description of store

	cout << setprecision(10); //Sets the precision of the output for digits to 10 because the default of 6 is too short
	
	//Creates a list of animals which represent the animals in the pet store
	list<Animal> listOfAnimals = {
		Animal("Zebra", "Horse but with stripes", 7900.43),
		Animal("Lion", "Horse but with teeth", 1230.12),
		Animal("Gecko", "Horse but with weird eyes", 55.50),
		Animal("Parrot", "Horse but with speech", 1000.00),
		Animal("Alligator", "Horse but with water powers", 890.89),
		Animal("Horse", "Horse but with horse", 99999.99),
	};

	//Intro
	cout << setw(40) << "Welcome to " << STORENAME << "!" << endl; //Title display
	cout << setw(55) << STOREDESCRIPTION << endl << endl; //Description display

	//input

	cout << "Please enter you last name: ";
	cin >> lastName;
	cout << endl;
	cout << "Please enter the date in format DD/MM/YYYY: ";
	cin >> date;
	cout << endl << endl;

	//Creates an iterator to iterate through animals in a loop
	list<Animal>::iterator it;

	for (it = listOfAnimals.begin(); it != listOfAnimals.end(); it++) {
		it->displayAnimalInfo(); //Displays the name, description and price of an animal

		int numPurchasedNow; //Number of a type of animal the user inputed to purchase

		//Allows the user to purchase an animal
		cout << "How many would you like to purchase(no negative numbers): ";
		cin >> numPurchasedNow;
		cout << endl;

		it->setNumPurchased(numPurchasedNow); //Sets the Animal object's variavle numPurchase to numPurchaseNow

		//Tells the user how many of an animal they purchased, and the total price.
		cout << "You purchased " << it->getNumPurchased() << " of the animal wich will cost a total of " << it->getTotalPrice() << "$" << endl << endl; 
	}

	//Results and confirmation of purchase
	cout << "The grand total for all the animals including shipping is " << grandTotal(listOfAnimals, SHIPPINGFEE) << "$" << endl;
	cout << "Press any character and hit enter to confirm the purchase: ";
	cin >> confirmation;
	cout << endl << "Purchase confirmed, thank you." << endl << endl;

	//Receipt generation
	genReceipt(listOfAnimals, lastName, date, STORENAME, SHIPPINGFEE);


	system("PAUSE");
	return 0;
}