#include "Animal.h"
#include <iostream>

using namespace std;

//Constructs the animal, sets numPurchased to 0 because no animals have been purchased at this point in the program
Animal::Animal(string name, string description, double price) : PRICE (price) {
	this->name = name;
	this->description = description;
	numPurchased = 0;
}

//Returns number of a type of animal purchased
int Animal::getNumPurchased() {
	return numPurchased;
}

double Animal::getPrice() {
	return PRICE;
}

//Sets numPurchased to the customer's number of purchased animals
void Animal::setNumPurchased(int numPurchased) {
	this->numPurchased = numPurchased;
}

//Calc the price of all of a type of animal purchased
double Animal::getTotalPrice() {
	return PRICE * (double)numPurchased;
}

string Animal::getReceiptDescrip() {
	return name + ": " + description;
}

//Displays the basic info of the animal
void Animal::displayAnimalInfo() {
	cout << "Name: " << name << endl;
	cout << "Description: " << description << endl;
	cout << "Price: " << PRICE << "$" << endl;
}