//Nolan Campbell, Mason Jones, Henry Drake 30102020
//Murphyville Halloweenttown Small Group Project
//This program will use functions to run modules based upon attractions at Murphyville Halloweentown

#include<iostream>
#include<string>
#include<iomanip>
#include<fstream>


using namespace std;

//////Globals for haunted movie theater module
//Enums for haunted movie theater modules
//Values first and last used to track where the iterator is in for-loops
enum days { Fri, Sat, Sun, Mon, Tue, Wed, Thu, FirstD = Fri, LastD = Thu };
enum times { Six, Seven, Eight, Nine, Ten, Eleven, Twelve, FirstT = Six, LastT = Twelve };
//Global constants of 2D array dimensions so that it can be used as a parameter in functions for haunted movie theater function
const int RTICKETSIZE = 7, CTICKETSIZE = 7;

void menu(); //Function that holds the program menu

//////Functions for Haunted Movie Theater module
void hauntedMovies(int tickets[][CTICKETSIZE]); //Function that will allow the user to purchase tickets to the haunted movie theater
//Used to find the next time slot available if the customers desired slot is already filled
void findNextSlot(int tickets[][CTICKETSIZE], int ticketPurchase, times& time, days& day);
void printDay(days day); //Uses a switch statement to print the string equivlaent to the enum value
void printTime(times time); //Uses a switch statement to print the string equivlaent to the enum value
void printTickets(int tickets[][CTICKETSIZE]); //Function that will print the ticket matrix


//////Functions for Costume Shop Module
void costumeShop(string CCodes[], string CDesc[], double CPrice[], bool CStatus[], string CCart[]); //Runs Costume Shop Module

//////Functions for Candy Store Module
void candyStore();
void selectionSort(string list[], int length);
void readCandyStore();




int main() {
	menu();

	system("PAUSE");
	return 0;
}

//Function that holds the program menu
void menu() {
	
	/////Variables for Costume Shop Module
	string CCodes[20];		// Array to hold the 3 character code for the costumes.
	string CDesc[20];		// Array to hold the description of the costumes.
	double CPrice[20];		// Array to hold prices of the costumes.
	bool CStatus[20];		// Costume Status. True == Available, False == Rented
	string CCart[20];		// Shopping cart array.
	int r = 0;
	string line;
	double pr = 0;

	ifstream inFile;
	inFile.open("CostumeShop.txt");

	// Looping through our arrays and initializing data via input file.
	for (r = 0; r < 20; r++)
	{
	
		CStatus[r] = true;	// Setting all costumes to true, since we have no customers yet.
		CCart[r] = "Empty"; // Array for shopping cart. Set to Empty for later use.

		// Process takes in a line up until a space or new line, and then assigns it to the array.
		inFile >> line;
		CCodes[r] = line;
		//cout << CCodes[r];

		inFile >> line;
		CDesc[r] = line;
		//cout << " " << CDesc[r];

		inFile >> pr;
		CPrice[r] = pr;
		//cout << " $" << CPrice[r] << endl;
	}

	inFile.close();

	//Variable declaration and definition
	const string MENULABEL = "Murphyville Halloweentown";
	bool stopMenu = false;
	int choice;

	//////Haunted Movie Theater Variable declaration/initalization
	//2D array filled with 10s to process ticket purchases, Declared in menu so that arra values are retained throughout the program
	int tickets[RTICKETSIZE][CTICKETSIZE];
	//Populate arrays with 10's
	for (int r = 0; r < RTICKETSIZE; r++)
		for (int c = 0; c < CTICKETSIZE; c++)
			tickets[r][c] = 10;

	//////menu
	cout << setfill('+') << setw(MENULABEL.length() + 4.0) << "" << endl;
	cout << "+ " << MENULABEL << " +" << endl;
	cout << setfill('+') << setw(MENULABEL.length() + 4.0) << "" << endl << endl << setfill(' ');

	//Runs the program until the user is ready to stop
	while (!stopMenu) {

		//Let's user decide which module they want to run
		cout << "Welcome to the Murphyville Halloweeentown attraction manager." << endl;
		cout << "This program is used to control each attraction in Halloweentown." << endl;
		cout << "Enter the number according to which module you want to run or -1 to exit" << endl << endl;
		cout << "Halloween Costume Shop = 1" << endl;
		cout << "Candy Store = 2" << endl;
		cout << "Haunted Movie Theater Tours = 3" << endl << endl;
		cout << "Input: ";
		cin >> choice;
		cout << endl;

		//Switch statement to decide which module to run
		switch (choice) {
		case 1:
			costumeShop(CCodes, CDesc, CPrice, CStatus, CCart);
			break;
		case 2:
			candyStore();
			break;
		case 3:
			hauntedMovies(tickets);
			break;
		case -1:
			cout << "Goodbye" << endl;
			stopMenu = true;
			break;
		default:
			cout << "Invalid input" << endl;
			break;
		}
	}
	
}

//////Haunted Movie Theater Module Functions
//Function that will allow the user to purchase tickets to the haunted movie theater
void hauntedMovies(int tickets[][CTICKETSIZE]) {
	//Nolan Campbell
	//This module will allow the user to purchase tickets to the haunted movie theater
	//If the time slot the user chose is full, the program will recomend a new slot for them whicha they can confirm or deny

	//////Local variables declaration and definition
	days day = FirstD; //Declaration and definition of days variable
	times time = FirstT; //Declaration and definition of times variable

	const string MODULETITLE = "Welcome to the Haunted Movie Theater Tour"; //Title of module, used to calculate banner length

	bool moduleRunning = true; //Checks to see if the module is still running
	char purchaseChoice; //Used to see if the user wants to purchase tickets at a new time slot

	int dayChoice, timeChoice; //Variables used to gather input from user and then assign it to the respective enum value
	int ticketPurchase; //How many ticekts the user would like to purchase
	int exit; //Used to decide if the user wants to continue or exit

	//Welcome banner
	cout << setw(MODULETITLE.length() + 4.0) << setfill('+') << "" << endl;
	cout << "+ " << MODULETITLE << " +" << endl;
	cout << setw(MODULETITLE.length() + 4.0) << setfill('+') << "" << setfill(' ') << endl << endl;

	while (moduleRunning) {
		//////Data Input
		cout << "The following prompts will guide through ticket purchasing." << endl;

		cout << "Enter the time you would like to purchase tickets on. (6-12)" << endl;
		cout << "Input: ";
		cin >> timeChoice;
		cout << endl;

		//Check to see if input is valid, will skip to the next iteration if invalid
		timeChoice -= 6;
		if (timeChoice >= 0 && timeChoice <= 6)
			time = static_cast<times>(timeChoice);
		else {
			cout << "Invalid Input" << endl;
			continue;
		}

		cout << "Enter the day you would like to purchase tickets on." << endl;
		cout << "Friday = 1, Saturday = 2, Sunday = 3, Monday = 4 \n Tuesday = 5, Wednseday = 6, Thursday = 7" << endl;
		cout << "Input: ";
		cin >> dayChoice;
		cout << endl;

		//Check to see if input is valid, will skip to the next iteration if invalid
		if (dayChoice >= 1 && dayChoice <= 7)
			day = static_cast<days>(dayChoice - 1);
		else {
			cout << "Invalid Input" << endl;
			continue;
		}

		cout << "How many tickets would you like to purchase(no more than ten): ";
		cin >> ticketPurchase;
		cout << endl;

		//Check to see if input is valid, will skip to the next iteration if invalid
		if (!(ticketPurchase >= 0 && ticketPurchase <= 10)) {
			cout << "Invalid Input" << endl;
			continue;
		}

		//Check to see if tickets are available
		if (tickets[static_cast<int>(time)][static_cast<int>(day)] - ticketPurchase >= 0) {
			tickets[static_cast<int>(time)][static_cast<int>(day)] -= ticketPurchase;
			cout << "Purchase successful" << endl << endl;
		}
		else { //If not find the next available slot that can hold the tickets
			cout << "The time slot you chose cannot handle your ticket amound, attempting to find new time slot." << endl;

			findNextSlot(tickets, ticketPurchase, time, day); //Finds the new time slot

			//Print the new time slot
			cout << "Your new time slot is on ";
			printDay(day);
			cout << " at ";
			printTime(time);
			cout << endl;

			//Ask if the user wants the new time slot
			cout << "Would you like to purchase your tickets in this time slot?(y/n): ";
			cin >> purchaseChoice;
			cout << endl;

			//If the user wants to purchase tickets then the cell will be updated. Also checks fo invalid input and skips to next iteration if found
			if (toupper(purchaseChoice) == 'Y') {
				tickets[time][day] -= ticketPurchase;
				cout << "Purchase successful" << endl << endl;
			}
			else if (!(toupper(purchaseChoice) == 'N')) {
				cout << "Invalid Input" << endl;
				continue;
			}
			else {
				cout << "Haunted Movie Theater apologizes for the inconvienence" << endl << endl;
			}
		}

		//Prompts the user to see if they want to purchase more tickets
		cout << "Would you like to purchase more tickets?" << endl;
		cout << "Enter a -1 to print the ticket matrix and exit," << endl;
		cout << "any other number entered will take you to the next step in purchasing your tickets" << endl;
		cout << "Input: ";
		cin >> exit;
		cout << endl;
		//Exits the loop if the user is done purchasing tickets
		if (exit == -1) {
			printTickets(tickets);
			moduleRunning = false;
		}
	}
}

//Used to find the next time slot available if the customers desired slot is already filled
void findNextSlot(int tickets[][CTICKETSIZE], int ticketPurchase, times& time, days& day) {
	times timeR = time; //Declares and defines the starting row.
	//Increments by one or resets it to firstT so that row does not reiterate a bad time or go out of bounds
	timeR = (timeR == LastT) ? FirstT : static_cast<times>(static_cast<int>(timeR) + 1);

	days dayC = day; //Declares and defines the starting collumn.
	//Increments by one or sets dayC to firstD so that collumn does not reiterate a bad day or goes out of bounds
	dayC = (time == LastT) ? (dayC == LastD) ? FirstD : static_cast<days>(static_cast<int>(dayC) + 1) : dayC;
	//Searches for the next possible time slot
	//dayC is in the outer loop instead of inner because the time should be 
	//searched through before the day so that the closest possible time slot is found
	for (dayC; dayC <= LastD; dayC = static_cast<days>(static_cast<int>(dayC) + 1)) {
		for (timeR; timeR != time; timeR = static_cast<times>(static_cast<int>(timeR) + 1)) {
			//Checks to see if the position of tickets has enough tickets available for purchase
			if (tickets[timeR][dayC] - ticketPurchase >= 0) {
				time = timeR; //Set time to the new time slot
				day = dayC; //Set day to the new day slot
				return;
			}

			//If the timeR reaches the end of the enum values, set it to zero
			if (timeR == LastT) {
				timeR = FirstT;
			}
		}

		//If the dayC reaches the end of the enum values, set it to zero
		if (dayC == LastD) {
			dayC = FirstD;
		}
	}

	//In the event that it is not possible for the customer to be able to purchase their tickets, they will be sent back to the menu
	if (timeR == time && dayC == day) {
		cout << "All sold out" << endl << endl;
		menu();
	}
}

//Function that will print the ticket matrix
void printTickets(int tickets[][CTICKETSIZE]) {

	const string MATRIXLABEL = "Ticket Availability Matrix"; //Label for matrix

	//Print label for matrix
	cout << setfill('+') << setw(MATRIXLABEL.length() + 4.0) << "" << endl;
	cout << "+ " << MATRIXLABEL << " +" << endl;
	cout << setfill('+') << setw(MATRIXLABEL.length() + 4.0) << "" << endl << endl << setfill(' ');

	//Prints each day across the top
	cout << "|" << setw(8) << "| ";
	for (days dayT = FirstD; dayT <= LastD; dayT = static_cast<days>(static_cast<int>(dayT) + 1)) {
		cout << setw(3);
		printDay(dayT);
		cout << " | ";
	}
	cout << endl;

	//Nested for loop with times than days iterators to control printing of tickets[]
	for (times timeR = FirstT; timeR <= LastT; timeR = static_cast<times>(static_cast<int>(timeR) + 1)) {
		cout << "| " << setw(4);
		printTime(timeR); //Prints each time down the left
		cout << " | ";

		for (days dayC = FirstD; dayC <= LastD; dayC = static_cast<days>(static_cast<int>(dayC) + 1)) {
			cout << setw(3) << tickets[timeR][dayC] << " | "; //Prints each ticket amount in its respective cell
		}
		cout << endl;
	}
	cout << endl;
}

//Uses a switch statement to print the string equivlaent to the enum value
void printDay(days day) {
	//Prints out the enum value as a stringbased on it's number
	switch (day) {
	case 0:
		cout << "Fri";
		break;
	case 1:
		cout << "Sat";
		break;
	case 2:
		cout << "Sun";
		break;
	case 3:
		cout << "Mon";
		break;
	case 4:
		cout << "Tue";
		break;
	case 5:
		cout << "Wed";
		break;
	case 6:
		cout << "Thu";
		break;
	}
}

//Uses a switch statement to print the string equivlaent to the enum value
void printTime(times time) {
	//Prints out the enum value as a stringbased on it's number
	switch (time) {
	case 0:
		cout << "6pm";
		break;
	case 1:
		cout << "7pm";
		break;
	case 2:
		cout << "8pm";
		break;
	case 3:
		cout << "9pm";
		break;
	case 4:
		cout << "10pm";
		break;
	case 5:
		cout << "11pm";
		break;
	case 6:
		cout << "12am";
		break;
	}
}

//////Costume Shop Module Functions
void costumeShop(string CCodes[], string CDesc[], double CPrice[], bool CStatus[], string CCart[]) {
	/*
	Henry Drake 10/29/20

	My module of the group project. Costume Shop.
	Group mates: Nolan C, Mason J, Henry Drake.

	Uses an input file and 1D arrays.
	Array data is taken from the input file, and the user is asked a series of prompts depending on their first selection.

	Side note: Other people who are doing this module mentioned that Ms. Hull allowed them to remove the $ in the txt file, but we need to re-add it in the cout statements.

	Side note: I was trying to create functions for these instead, since the last requirement from the Return segment of the module asks the user if they want to rent anything different.
	I had an issue with my visual studio however, and for some reason my functions were all correct, but I could not print any data from my arrays. they were all passed in by value, and had no errors or warnings.
	Didn't even get a build failure, or any error when I tried to run the function, The hard coded Cout lines worked, but nothing from my arrays would print.
	I tried to use the functions, but I just wanted to note know something wasn't right with my visual studio, or it just wasn't working.

	*/

	

	

	string Uans;				// Response to original prompt short for "your answer", with your replaced with u, and answer replaces with ans
	string line;				// String used to hold input from the file. Only used for the code and the description.
	double pr = 0, total = 0;	// Double values, one for the total price of the shopping cart, and the other "pr" to hold the price of the costumes from the input file.
	int r = 0;					// 1D array loops use this, meant as "row" for ease of understanding.
	string CCodeR;				// The user response to the code of the costume they want to rent.
	char compA;					// Means "Complete Answer". Not meant as a complete answer, but complete referring to complete basket prompt. Used for more than just that prompt, also used in switch.
	bool completeO = false;		// Means "Complete Order", Mostly self explanitory. Bool value to keep simple for the flag controlled while loop.

	

	// Opening menu to the user.
	cout << "Welcome to the Murphyville Halloween Costume Shop!\n";
	cout << "Are you renting or returning a costume?\n"
		<< "To rent a costume answer 'rent', if you are returning a costume answer 'return'\n"
		<< "What will it be today? answer: ";

	cin >> Uans;


	if (Uans == "rent")
	{

		// check to see if costume is in stock (bool == true)
		// sum order
		// ask customer if they are ready to pay
		// if not, ask if they want to add or remove to their order
		// continue looping through this until they confirm order is correct.
		// Once order confirmed, update the status of all rented costumes to (bool == false) false meaning they are not available.
		// ask if they have anything to return. y = return logic, n = thank customer and exit.

		// Since the order has not been completed, loop.
		while (completeO == false)
		{
			// Endl to seperate from the cout's
			cout << endl;

			// Loop that is checking what costumes are available for rent. Prints out available costumes.
			for (r = 0; r < 20; r++)
			{
				// Checking each bool that matches costumes in other arrays if they are in stock. If its in stock, print it.
				if (CStatus[r] == true)
				{
					cout << CCodes[r] << " ";
					cout << CDesc[r] << " ";
					cout << " $" << CPrice[r] << endl;	// $ was tacked on, since Ms. Hull allowed module programmers to remove it from the input file.
				}


			}

			// Talking to the user after we displayed the list above.
			cout << endl << "Here is the list of available costume(s) for rent.\n"
				<< "Please enter the 3 letter code of the costume you would like to rent: ";

			cin >> CCodeR;

			// Loop for renting. Since we aren't using a switch statement, we loop through the arrays until we find the correct costume.
			for (r = 0; r < 20; r++)
			{
				// If the code input matches one of the codes that are available, add the costume to the total list & set the bool to false since there is only one.

				if (CCodeR == CCodes[r] && CStatus[r] == true)
				{
					// Adds designated price to the Total cost of the shopping cart.
					total += CPrice[r];

					// Adding the description of the costume to our cart array.
					CCart[r] = CDesc[r];

					// Setting the costume availability to false, since the user is now renting it.
					CStatus[r] = false;
				}

			}

			// Talking to the user about their shopping cart.
			cout << "\nYour shopping cart has these/this costume(s): ";

			// If there is a bucket in the cart array that doesn't say Empty, Cout the costume description.
			for (r = 0; r < 20; r++)
			{
				if (CCart[r] != "Empty")
					cout << CCart[r] << ", ";
			}

			// Reminding the user about their total cost and items in cart.
			cout << "\nThe total cost is: $" << total
				<< "\nAre you ready to pay?"
				<< "\nAnswer with 'y' Or 'n' Answer: ";

			cin >> compA;

			// Checking to see if the user wants to continue renting more, or if they want to remove an item from their cart.
			switch (compA)
			{
			case 'y':
				cout << "\nThank you for shopping at the Murphyville Halloween Costume shop!\n";
				completeO = true;
				break;

				// Since n, we talk to the user and start another statement to determine what to remove.
			case 'n':
				completeO = false;

				cout << "\nWould you like to remove an item from your shopping cart?"
					<< "\nAnswer with 'y' or 'n'. Your answer: ";

				cin >> compA;

				// Switch that determines what to remove from the cart.
				switch (compA)
				{
				case 'y':
					cout << "\nYour shopping cart has these items: ";
					// Telling our user what items they have in their cart, looping through the cart array one at a time.
					for (r = 0; r < 20; r++)
					{
						if (CCart[r] != "Empty")
							cout << CCart[r] << ", ";
					}

					cout << "\nWhich item do you want to remove: ";
					cin >> CCodeR;

					// If the item code of the item they want to remove isn't available, and it is in their shopping cart, remove it and remove the price.
					for (r = 0; r < 20; r++)
					{
						if (CCodeR == CCodes[r] && CStatus[r] == false)
						{

							// remove item from shopping cart, initialize for others to buy.
							CStatus[r] = true;
							CCart[r] = "Empty";

							// subtract the price from the total cost. let the user know their total price, and their cart now.
							total -= CPrice[r];
							cout << "Your total price is now: $" << total;
							cout << "\nAnd your shopping cart has these items: ";
							for (r = 0; r < 20; r++)
							{
								if (CCart[r] != "Empty")
									cout << CCart[r] << ", ";
							}
							cout << endl << endl;
						}
					}

					break;

				case 'n':
					break;
				}

				break;
			}

		}


	}

	// User wants to return a costume in their shopping basket.
	else if (Uans == "return")
	{

		// While loop to check if they want to keep looping.
		while (completeO == false)
		{
			cout << "\nWhat is the code of the costume you are returning?"
				<< "\nEnter here: ";

			cin >> CCodeR;

			// Looping through to check if it is a valid code, and not available for purchase.
			for (r = 0; r < 20; r++)
			{
				if (CCodeR == CCodes[r] && CStatus[r] == false)
				{	// Since it wasnt available for purchase, return the item to the store. If the item is false, we can tell that they have it in their basket.
					cout << "\nThank you for returning: " << CCodes[r] << " " << CDesc[r] << ". This item has been returned to the store inventory.";
					CStatus[r] = true;
				}

			}

			cout << "\nIs there another item you have to return?"
				<< "\nPlease respond with 'y' or 'n':";

			cin >> compA;

			// Switch to ask user if they would like to return more, or exit.
			switch (compA)
			{
			case 'y':
				completeO = false;

				break;
			case 'n':
				// Thanking our user and breaking the loop.
				cout << "\nThank you for shopping at the Murphyville Halloween Costume Shop!\n";

				completeO = true;
				break;
			}

		}

	}


	
}

//////Candy Store Functions
void candyStore() {
	//Mason Jones
	//This module will take a list of candy and sort it and display it on a wall.

	ifstream inFile;
	string candy[20];
	string lineStr;
	string fileName;

	inFile.open("CandyStore.txt");


	for (int i = 0; i < 20; i++)
	{
		getline(inFile, candy[i]);
	}

	selectionSort(candy, 20);

	//while (getline(inFile, lineStr))
	//{
	//    cout << lineStr << '\n';

	//}

	for (int i = 0; i < 20; i++)
	{

		cout << candy[i] << '\n';

	}
	const int RSIZE = 5, CSIZE = 4;
	string candyStore[RSIZE][CSIZE];
	int r, c;
	// initializing the 2D array
	  // for (r = 0; r < RSIZE; r++)
	   //    for (c = 0; c < CSIZE; c++)// prints names + scores array
	   //        candyStore[r][c] = 0; // stores a 0 in each element of array


	for (int i = 0; i < 4; i++)
	{
		candyStore[0][i] = candy[i];
		candyStore[1][i] = candy[i + 4];
		candyStore[2][i] = candy[i + 8];
		candyStore[3][i] = candy[i + 12];
		candyStore[4][i] = candy[i + 16];

	}
	cout << endl;
	for (r = 0; r < RSIZE; r++)
	{
		for (c = 0; c < CSIZE; c++)
		{
			cout << candyStore[r][c] << "     ";
		}
		cout << endl;
	}
	//cout << endl << endl;
	cout << "Please enter the name for an output file: ";
	cin >> fileName;

	ofstream outFile(fileName.c_str());

	for (r = 0; r < RSIZE; r++)
	{
		for (c = 0; c < CSIZE; c++)
		{
			outFile << candyStore[r][c] << "     ";
		}
		outFile << endl;
	}

	inFile.close();

}

void selectionSort(string list[], int length)

{

	int index;

	int smallestIndex;

	int location;

	string temp;

	for (index = 0; index < length; index++)

	{

		smallestIndex = index;

		for (location = index; location < length; location++)

			if (list[location] < list[smallestIndex])

				smallestIndex = location;

		temp = list[smallestIndex];

		list[smallestIndex] = list[index];

		list[index] = temp;

	}

}
void readCandyStore()
{
	ifstream inFile;
	string lineStr;
	string fileStr;
	inFile.open("CandyStore.txt");



	while (getline(inFile, lineStr))
	{
		cout << lineStr << '\n';

	}
	//return 0;
}