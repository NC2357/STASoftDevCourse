//Nolan Campbell 10112020
//CH9 Pair Share Battle Bots Fundraiser
//This program will read each sponsor's name and Sale and assign them their respective sales level - (G)old, (S)ilver, (B)ronze, (C)oal
//It will also tell the user the highest Sale, the lowest Sale, and those students who sales are in the coal and gold levels
//It will also average the sales
//Outputs data to both file and cout as the assignment is not specifc on which output type to use

#include<iostream>
#include<string>
#include<fstream>
#include<string>
#include <iomanip>

using namespace std; //The number of students in my class and file

const int NUMSTUDENT = 26; //The number of students

//Here is our new structure
struct studentSalesType {
	string teacherName; //first name
	string studentName; //last name
	double Sale; //How much a sponsor donated
	char attainment; //Level of sponsorship, (G)old, (S)ilver, (B)ronze, (C)oal
};

//Prototypes go here
void getData(ifstream& inFile, studentSalesType spoinsorList[]); //Read data from fileand store in array
void calculateLevel(studentSalesType sponsorList[]);  //Function to calculate sponsor level
void printResults(ofstream& outFile, studentSalesType sponsorList[]); //function to print results
double lowestSale(studentSalesType sponsorList[]); //Finds the lowest Sale
double highestSale(studentSalesType sponsorList[]); //Finds the highest Sale
double averageSale(studentSalesType sponsorList[]); //Finds the average Sale


//main line processing

int main() {
	studentSalesType sponsorList[NUMSTUDENT]; //Declare studentSalesType array sponsorList with size of NUMSTUDENT
	ifstream inFile("StudentSalesData.txt"); //Declares the input string file identifier and opens he file
	ofstream outFile("StudentSalesDataOut.txt"); //Declares the output string file identifier and opens he file

	//Make sure files are valid
	if (!inFile) {
		cout << "Unable to open input file, program terminated";
		return 1; //This will give status code != 0 - abort
	}

	if (!outFile) {
		cout << "Unable to create output file, program terminated";
		return 2; //This will give status code != 0 - abort
	}
	//Intro
	cout << "This program will read each student and their sponsor's last name and Sale and assign them \ntheir respective sales level - (G)old, (S)ilver, (B)ronze, (C)oal "
		 << "It will also tell the user the highest Sale, \nthe lowest Sale, and those students who sales are in the coal and gold levels "
		 << "and it will also average the sales" << endl << endl;


	//Call function to read data from file and store in array
	getData(inFile, sponsorList);
	//Call function to calculate grade
	calculateLevel(sponsorList);
	//Call function to print results
	printResults(outFile, sponsorList);

	outFile.close();
	inFile.close();
	system("PAUSE");
	return 0;
}

//Read data from file and store in array
void getData(ifstream& inFile, studentSalesType sponsorList[]) {
	for (int i = 0; i < NUMSTUDENT; i++) {
		inFile >> sponsorList[i].teacherName >> sponsorList[i].studentName >> sponsorList[i].Sale;
	}
}

//Function to calculate grade
void calculateLevel(studentSalesType sponsorList[]) {
	//Uses switch statement to select what attainment the Sale applies to.
	for (int i = 0; i < NUMSTUDENT; i++) {
		switch ((int)sponsorList[i].Sale / 10) {
		case 10: case 9:
			sponsorList[i].attainment = 'G';
			break;
		case 8:
			sponsorList[i].attainment = 'S';
			break;
		case 7: 
			sponsorList[i].attainment = 'B';
			break;
		case 6: case 5: case 4: case 3: case 2: case 1: case 0:
			sponsorList[i].attainment = 'C';
		} //End Switch
	}
}

//function to print results
void printResults(ofstream& outFile, studentSalesType sponsorList[]) {
	double lowest = lowestSale(sponsorList);
	double highest = highestSale(sponsorList);
	double average = averageSale(sponsorList);
	//Heading first, then print array data
	cout << setw(20) << left << "Teacher Last Name"
		<< setw(20) << left << "Student Last Name"
		<< setw(15) << right << "Sales"
		<< setw(15) << right << "Attainment" << endl;

	outFile << setw(20) << left << "Teacher Last Name"
		<< setw(20) << left << "Student Last Name"
		<< setw(15) << right << "Sales"
		<< setw(15) << right << "Attainment" << endl;


	for (int i = 0; i < NUMSTUDENT; i++) {
		cout << setw(20) << left << sponsorList[i].teacherName
			<< setw(20) << left << sponsorList[i].studentName
			<< setw(14) << right << sponsorList[i].Sale << "$"
			<< setw(15) << right << sponsorList[i].attainment << endl;


		outFile << setw(20) << left << sponsorList[i].teacherName
			<< setw(20) << left << sponsorList[i].studentName
			<< setw(14) << right << sponsorList[i].Sale << "$"
			<< setw(15) << right << sponsorList[i].attainment << endl;
	}

	cout << endl << "The lowest Sale is: " << lowest << "$" << endl;
	cout << "The students who raised this lowest are: " << endl;

	outFile << endl << "The lowest Sale is: " << lowest << "$" << endl;
	outFile << "The student who raised this lowest are: " << endl;

	for (int i = 0; i < NUMSTUDENT; i++) {
		if (sponsorList[i].Sale == lowest) {
			cout << sponsorList[i].studentName << endl;
			outFile << sponsorList[i].studentName << endl;
		}
	}

	cout << endl << "The highest Sale is: " << highest << "$" << endl;
	cout << "The students who raised this highest are: " << endl;

	outFile << endl << "The highest Sale is: " << highest << "$" << endl;
	outFile << "The students who raised this highest are: " << endl;

	for (int i = 0; i < NUMSTUDENT; i++) {
		if (sponsorList[i].Sale == highest) {
			cout << sponsorList[i].studentName << endl;
			outFile << sponsorList[i].studentName << endl;
		}
	}

	cout << endl << "The average Sale is " << average << "$" << endl << endl;
	outFile << endl << "The average Sale is " << average << "$" << endl << endl;

	cout << "Those students who acheived the level of Gold are presented below:" << endl;
	outFile << "Those students who acheived the level of Gold are presented below:" << endl;

	for (int i = 0; i < NUMSTUDENT; i++) {
		if (sponsorList[i].attainment == 'G') {
			cout << sponsorList[i].studentName << endl;
			outFile << sponsorList[i].studentName << endl;
		}
	}
	
	cout << endl;
	outFile << endl;

	cout << "Those students who made the level Coal and will have to clean the robotics lab are listed below:" << endl;
	outFile << "Those students who made the level Coal and will have to clean the robotics lab are listed below:" << endl;

	for (int i = 0; i < NUMSTUDENT; i++) {
		if (sponsorList[i].attainment == 'C') {
			cout << sponsorList[i].studentName << endl;
			outFile << sponsorList[i].studentName << endl;
		}
	}

	cout << endl;
	outFile << endl;
}

//Finds the lowest Sale
double lowestSale(studentSalesType sponsorList[]) {
	double lowest = 100;

	for (int i = 0; i < NUMSTUDENT; i++) {
		lowest = (sponsorList[i].Sale < lowest) ? sponsorList[i].Sale : lowest; //Set lowest equal to the current if it is lower
	}
	return lowest;
}

//Finds the highest Sale
double highestSale(studentSalesType sponsorList[]) {
	double highest = 0;

	for (int i = 0; i < NUMSTUDENT; i++) {
		highest = (sponsorList[i].Sale > highest) ? sponsorList[i].Sale : highest; //Set highest equal to the current if it is higher
	}
	return highest;
}

//Finds the average Sale
double averageSale(studentSalesType sponsorList[]) {
	double sum = 0;
	for (int i = 0; i < NUMSTUDENT; i++) {
		sum += sponsorList[i].Sale; //Adds the up Sales to get the total
	}
	return sum / NUMSTUDENT; //Calculates and returns the average
}