//Nolan Campbell 08122020
//Room Mate Picker With Overloaded Functions
//This program will help you determine if you are compatible with another friend
//as a potential post high-school. It will ask a series of questions and determine
//if you and the possible roomate are a match

#include<iostream>
#include<iomanip>
#include<string>
#include <fstream>

using namespace std;

const int NUM_OF_Q = 7; //Number of questions in survey
const double COMPATIBILITY_PERCENT = 75.00; //Minimum match percentage for users to be roomate compatible

bool areTheyFit(ofstream &outputFile); //Function to ask questions concerning roomate compatibility

template <class Type>
bool match(Type myAnswer, Type theirAnswer); //Compares two pieces of data of the same type, and returns true if they match

template <class Type>
void outputMatch(ofstream &outputFile, Type myAnswer, Type theirAnswer); //Writes a match to the file

template <class Type>
void outputQuestion(ofstream &outputFile, string question, bool isMatch, Type myAnswer, Type theirAnswer);//Prints out a question with if it is a match, and answers

void outputFinalResults(ofstream &outputFile, int nbrMatched, double percent, bool isCompatible); //Outputs the final results to the file

void fileToCout(string fileName); //Copy contents of file into standard output

/*void match(string myAnswer, string theirAnswer, int& matched);
void match(int myAnswer, int theirAnswer, int& matched);
void match(double myAnswer, double theirAnswer, int& matched);
void match(char myAnswer, char theirAnswer, int& matched);*/

int main() {
	string yourName, applicantName, fileName;
	ofstream outputFile;

	//Talk to user
	cout << "Room Mate Picker\n"
		<< "This program will help you determine if you are compatible with another friend\n"
		<< "as a potential post high-school. It will ask a series of questions and determine\n"
		<< "if you and the possible roomate are a match" << endl << endl;

	do {
		cout << "Before starting, please enter a file name to output to results to(no spaces): ";
		cin >> fileName;
		cout << endl;

		fileName += ".txt";//Add text file extension
		outputFile.open(fileName.c_str()); //Open output file
	} while (!outputFile.is_open());

	cout << fixed << showpoint << setprecision(1); //Sets desired decimal precision for cout
	outputFile << fixed << showpoint << setprecision(1); //Sets desired decimal precision for outputFile
	
	cin.ignore();
	cout << "Enter your name: ";
	getline(cin, yourName);
	cout << endl;

	cout << "Enter your name applicant: ";
	getline(cin, applicantName);
	cout << endl;

	cout << "Prepare " << yourName << " and " << applicantName << "! Now you will be asked some questions." << endl << endl;

	outputFile << left << "Your name: " << setw(24) << yourName << " " << "Applicant Name: " << setw(20) << applicantName << endl << endl;

	//Beginning of my questions
	if (areTheyFit(outputFile))
		cout << "Meet my new room mate " << applicantName << endl;
	else
		cout << "We are incompatible " << endl;

	outputFile.close();
	fileToCout(fileName);
}

//Function to ask questions concerning roomate compatibility
bool areTheyFit(ofstream &outputFile) {	
	string questions[NUM_OF_Q] = { "1. What time do you like to go to bed 9, 10, 3? ", "2. What time do you wake up ?",
		"3. Great, now what about your GPA? 2.0? 3.0? ","4. What college do you go to? ", "5. What is you major?",
		"6. Do you have dogs, (Y)es or (N)o? ", "7. What is your preffered room temperature?"};

	int nbrMatched = 0;
	bool tempMatch; //Used to temporarily hold match data for a question, so that match function only has to be called once
	bool isCompatible; //Used to decide if roomates are compatible
	double percent; //Used to hold percent of match

	//Variables for answers for roomate searcher
	int myAnswerQ1;
	int myAnswerQ2;
	double myAnswerQ3;
	string myAnswerQ4;
	string myAnswerQ5;
	char myAnswerQ6;
	int myAnswerQ7;

	//Variables for answers for applicant
	int theirAnswerQ1;
	int theirAnswerQ2;
	double theirAnswerQ3;
	string theirAnswerQ4;
	string theirAnswerQ5;
	char theirAnswerQ6;
	int theirAnswerQ7;

	//First question (int)
	while (true) {
		cout << questions[0];

		cout << endl << "Your answer: ";
		cin >> myAnswerQ1;
		cout << "Applicant Answer: ";
		cin >> theirAnswerQ1;
		cout << endl;
		
		if (!(myAnswerQ1 >0 && myAnswerQ1 <= 12 && theirAnswerQ1 > 0 && theirAnswerQ1 <= 12))
			cout << "Invalid input, try again" << endl << endl;
		else
			break;
	}

	tempMatch = match(myAnswerQ1, theirAnswerQ1);
	nbrMatched += tempMatch;
	outputQuestion(outputFile, questions[0], tempMatch, myAnswerQ1, theirAnswerQ1);

	//Second question (int)
	while (true) {
		cout << questions[1];

		cout << endl << "Your answer: ";
		cin >> myAnswerQ2;
		cout << "Applicant Answer: ";
		cin >> theirAnswerQ2;
		cout << endl;

		if (!(myAnswerQ2 > 0 && myAnswerQ2 <= 12 && theirAnswerQ2 > 0 && theirAnswerQ2 <= 12)) 
			cout << "Invalid input, try again" << endl << endl;
		else
			break;
	}
	

	tempMatch = match(myAnswerQ2, theirAnswerQ2);
	nbrMatched += tempMatch;
	outputQuestion(outputFile, questions[1], tempMatch, myAnswerQ2, theirAnswerQ2);

	//Third question (double)
	while (true) {
		cout << questions[2];

		cout << endl << "Your answer: ";
		cin >> myAnswerQ3;
		cout << "Applicant Answer: ";
		cin >> theirAnswerQ3;
		cout << endl;

		if (!(myAnswerQ3 >= 0 && myAnswerQ3 <= 4 && theirAnswerQ3 >= 0 && theirAnswerQ3 <= 4)) {
			cout << "Invalid input, try again" << endl << endl;
		}
		else
			break;
	}

	tempMatch = match(myAnswerQ3, theirAnswerQ3);
	nbrMatched += tempMatch;
	outputQuestion(outputFile, questions[2], tempMatch, myAnswerQ3, theirAnswerQ3);

	//Fourth question (string)
	cout << questions[3];

	cin.ignore();
	cout << endl << "Your answer: ";
	getline(cin, myAnswerQ4);
	cout << "Applicant Answer: ";
	getline(cin, theirAnswerQ4);
	cout << endl;

	tempMatch = match(myAnswerQ4, theirAnswerQ4);
	nbrMatched += tempMatch;
	outputQuestion(outputFile, questions[3], tempMatch, myAnswerQ4, theirAnswerQ4);

	//Fifth question (string)
	cout << questions[4];

	cout << endl << "Your answer: ";
	getline(cin, myAnswerQ5);
	cout << "Applicant Answer: ";
	getline(cin, theirAnswerQ5);
	
	cout << endl;

	tempMatch = match(myAnswerQ5, theirAnswerQ5);
	nbrMatched += tempMatch;
	outputQuestion(outputFile, questions[4], tempMatch, myAnswerQ5, theirAnswerQ5);

	//Sixth question (char)
	while (true) {
		cout << questions[5];
		cout << endl << "Your answer: ";
		cin >> myAnswerQ6;
		cout << "Applicant Answer: ";
		cin >> theirAnswerQ6;
		cout << endl;
		
		if (!((toupper(myAnswerQ6) == 'N' || toupper(myAnswerQ6) == 'Y') && (toupper(theirAnswerQ6) == 'N' || toupper(theirAnswerQ6) == 'Y'))) {
			cout << "Invalid input, try again" << endl << endl;
		}
		else
			break;
	}

	tempMatch = match(myAnswerQ6, theirAnswerQ6);
	nbrMatched += tempMatch;
	outputQuestion(outputFile, questions[5], tempMatch, myAnswerQ6, theirAnswerQ6);

	//Seventh question (int)
	cout << questions[6];

	cout << endl << "Your answer: ";
	cin >> myAnswerQ7;
	cout << "Applicant Answer: ";
	cin >> theirAnswerQ7;
	cout << endl;

	tempMatch = match(myAnswerQ7, theirAnswerQ7);
	nbrMatched += tempMatch;
	outputQuestion(outputFile, questions[6], tempMatch, myAnswerQ7, theirAnswerQ7);

	//Compabtiblilty determinations
	percent = (double(nbrMatched) / NUM_OF_Q) * 100; //Determine percent compatible
	isCompatible = (percent >= COMPATIBILITY_PERCENT) ? true : false; //Determine if it meets percentage threshold
	outputFinalResults(outputFile, nbrMatched, percent, isCompatible); //Ouptut the final results to file

	//Return based on compatibility results
	if (isCompatible)
		return true;
	else
		return false;
}

//Compares two pieces of data of the same type, and returns true if they match
template <class Type>
bool match(Type myAnswer, Type theirAnswer) {
	return (myAnswer == theirAnswer); //Checks the value of both "answers" and returns true if they match
}

//Writes a match to the file
template <class Type>
void outputMatch(ofstream &outputFile, Type myAnswer, Type theirAnswer) {
	//Ouputs answers in preffered format
	outputFile << left << "Your answer: " << setw(20) << myAnswer << " " << "Applicant Answer: " << setw(20) << theirAnswer << endl;
}

//Prints out a question with if it is a match, and answers
template <class Type>
void outputQuestion(ofstream &outputFile, string question, bool isMatch, Type myAnswer, Type theirAnswer) {
	outputFile << question << endl; //Output the question
	outputMatch(outputFile, myAnswer, theirAnswer); //Then the question and answer
	outputFile << "Match? "; //Then whether it is a match or not
	if (isMatch)
		outputFile << "Yes";
	else
		outputFile << "No";
	outputFile << endl << endl;
}

//Outputs the final results to the file
void outputFinalResults(ofstream &outputFile, int nbrMatched, double percent, bool isCompatible) {
	//Let's user know the questions have ended
	outputFile << "Final Results:" << endl;
	//Prints number of matched answers and percentage of it in preffered format
	outputFile << left << "Answers matched: " << setw(16) << nbrMatched << " " << "Percentage of match: " << setw(6) << percent << left << "%" << endl;
	outputFile << "Compatible? "; //Tells the users if they are compatible roomates
	if (isCompatible)
		outputFile << "Yes";
	else
		outputFile << "No";
	outputFile << endl << endl;
}

void fileToCout(string fileName) {
	//Effectivley copies the contents of the file and prints them to cout
	cout << endl << endl << endl << ifstream(fileName).rdbuf();
}


/*void match(string myAnswer, string theirAnswer, int& matched) {
	if (myAnswer == theirAnswer) 
		matched++;
}
void match(int myAnswer, int theirAnswer, int& matched) {
	if (myAnswer == theirAnswer) 
		matched++;
}
void match(double myAnswer, double theirAnswer, int& matched) {
	if (myAnswer == theirAnswer)
		matched++;
}
void match(char myAnswer, char theirAnswer, int& matched) {
	if (toupper(myAnswer) == toupper(theirAnswer))
		matched++;
}*/

