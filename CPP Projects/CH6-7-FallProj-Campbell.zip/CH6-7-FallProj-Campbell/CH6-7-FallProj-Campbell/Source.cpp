//Nolan Campbell 221020
//CH6/7 Fall Project
//This program will translate the iLoveFall.txt file into pig-latin and write it to an output file.
//Both files will then be printed onto the screen, and the number of each unique letter in "Autumn" 
//will be counted from pigLaitnFall.txt and displayed

#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>

using namespace std;

void getNextWord(ifstream& iLoveFall, char& ch, string& word);//Function to build a word
void readLoveFall(); //Prints contents of iLoveFall.txt to standard output
void readPigLatinFall(); //Prints contents of pigLatinFall.txt to standard output
//Counts how many of each unique letter in "Autumn" is found in pigLatinFall.txt
void countAutumn(int& numA, int& numU, int& numT, int& numM, int& numN);
string pigLatinString(string str); //Main function to create pig-latin string
string rotate(string pStr, string::size_type len); //Rotates the letter in a string
bool isVowel(char ch); //Is the character a vowel
bool isPuncutation(char ch); //Is the character a puncuation

int main() {
	// local variables and identifier
	ifstream iLoveFall; //input file identifier
	ofstream pigLatinFall; //output file identifier
	char ch; //Used to read each character of end file
	string str; //Word in the iLoveFall to be processed
	//Declare and defines each integer that will count the number of each unique letter in "Autumn" found in pigLatinFall
	int numA = 0, numU = 0, numT = 0, numM = 0, numN = 0;

	iLoveFall.open("iLoveFall.txt"); //Opening iLoveFall.txt
	pigLatinFall.open("pigLatinFall.txt"); //Opening pigLatinFall.txt

	if (!iLoveFall) {
		cout << "Error, unable to locate file";
		return 1; //Returns 1 if error encountered, otherwide error returns 0
	}

	//Program description to user
	cout << "This program will translate the iLoveFall.txt file into pig-latin and write it to an output file." << endl;
	cout << "Both files will then be printed onto the screen, and the number of each unique" << endl;
	cout << "letter in \"Autumn\" will be counted and displayed" << endl;

	//Main file processing loop

	iLoveFall.get(ch);
	while (iLoveFall) {

		while (ch != '\n') { //while not equal to a carriage return
			if (ch == ' ') { //if the char is a space, just move it to pigLatinFall
				pigLatinFall << ch;
				iLoveFall.get(ch);
			}
			else { 	//If not a return and not a space, then process the word
				getNextWord(iLoveFall, ch, str);//Call next word funtion
				pigLatinFall << pigLatinString(str);//Process the next word and write it to pigLatinFall

			}
		} //end of while loop that processes non end-lines
		pigLatinFall << endl;
		iLoveFall.get(ch);
	}


	iLoveFall.close(); //Closing iLoveFall.txt
	pigLatinFall.close(); //Closing pigLatinFall.txt file

	//The part of the project that will print both files to standard outpur and 
	//calculate the number of unique letters in pigLatinFall base upon "Autumn"

	//Header for the iLoveFall printout
	cout << endl << endl; //Seperates header from previous output
	cout << setw(24) << setfill('*') << "" << endl;
	cout << "* iLoveFall in English *" << endl;
	cout << setw(24) << setfill('*') << "" << endl;

	readLoveFall(); //Call to print iLoveFall

	//Header for the pigLatinFall printout
	cout << endl << endl << endl; //Seperates header from previous output
	cout << setw(26) << setfill('*') << "" << endl;
	cout << "* iLoveFall in Pig-Latin *" << endl;
	cout << setw(26) << setfill('*') << "" << endl;

	readPigLatinFall(); //Call to print pigLatinFall

	//Call to count the number of occurences each unique letter of "Autumn" occured
	countAutumn(numA, numU, numT, numM, numN); 

	//Prints each number of unique letters found
	cout << endl << endl; //Seperates numbers from the file printout
	cout << "Below is the number of unique letters found in pigLatinFall based upon the word \"Autumn\"" << endl;
	cout << "Number of A/a's found: " << numA << endl;
	cout << "Number of U/u's found: " << numU << endl;
	cout << "Number of T/t's found: " << numT << endl;
	cout << "Number of M/m's found: " << numM << endl;
	cout << "Number of N/n's found: " << numN << endl;

	cout << endl; //Creates a blank line between the exit prompt and previous output
	system("PAUSE"); //Pauses
	return 0; //Ends
}

//Function to build a word
void  getNextWord(ifstream& iLoveFall, char& ch, string& word) {
	word = ch; //Set string first letter = character

	while (ch != ' ' && ch != '\n') {
		iLoveFall.get(ch); //Reads next word in the file
		if (ch != ' ' && ch != '\n') //IF the character read is not = to space or return
			word = word + ch; //Concats the next character to existing word part
	}
}

//Prints contents of iLoveFall.txt to standard output
void readLoveFall() {
	ifstream iLoveFall("iLoveFall.txt"); //Re-opens the file
	string text = "";//Makes sure new lines occur
	int numReturns; //Used in calculation of how many returns are needed
	//Reads through the file
	while (!iLoveFall.eof()) {
		string line;
		//Gets the next line in the file
		getline(iLoveFall, line);
		text += line; //Adds the line to the existing text
	}

	numReturns = text.length() / 80; //Calculates num returns needed

	//This loop distrubutes carriage returns throughout the text to ensure lines are a reasonable length.
	for (int i = 1; i <= numReturns; i++) {
		int returnPlace = 81 * i; //The first possible location of the carriage return
		//Loops until a space is found to insert the carriage return so words are not cut.
		while (text[returnPlace] != ' ') {
			returnPlace--;
		}
		text.insert(returnPlace + 1, "\n"); //Inserts the carriage return after the space
	}
	cout << text; //Prints the file contents
	iLoveFall.close(); //Closes the file
}

//Prints contents of pigLatinFall.txt to standard output
void readPigLatinFall() {
	ifstream pigLatinFall("pigLatinFall.txt"); //Re-opens the file
	string text = "";
	int numReturns; //Used in calculation of how many returns are needed
	//Reads through the file
	while (!pigLatinFall.eof()) {
		string line;
		//Gets the next line in the file
		getline(pigLatinFall, line);

		text += line; //Adds the line to the existing text
	}
	
	numReturns = text.length() / 80; //Calculates num returns needed

	//This loop distrubutes carriage returns throughout the text to ensure lines are a reasonable length.
	for (int i = 1; i <= numReturns; i++) {
		int returnPlace = 81 * i; //The first possible location of the carriage return

		//Loops until a space is found to insert the carriage return so words are not cut.
		while (text[returnPlace] != ' ') {
			returnPlace--;
		}
		text.insert(returnPlace+1, "\n"); //Inserts the carriage return after the space
	}
	cout << text; //Prints the file contents
	pigLatinFall.close(); //Closes the file
}

//Counts how many of each unique letter in "Autumn" is found in pigLatinFall.txt
void countAutumn(int& numA, int& numU, int& numT, int& numM, int& numN) {
	ifstream pigLatinFall("pigLatinFall.txt"); //Re-opens the file
	char ch; //Declares a char variable to use to get chars from file
	//Loops through each char in the file
	while (!pigLatinFall.eof()) {
		pigLatinFall.get(ch); //Gets the next char
		//Checks to see if the char is a unique letter found in "Autumn" 
		//and if so, add one to the counter of the unique letter the char matches
		switch (toupper(ch)) {
			case 'A': 
				numA++;
				break;
			case 'U':
				numU++;
				break;
			case 'T':
				numT++;
				break;
			case 'M':
				numM++;
				break;
			case 'N':
				numN++;
				break;
		}
	}

	pigLatinFall.close(); //Closes the file
}

//Main function to create pig-latin string
string pigLatinString(string pStr) {
	//Local variables
	string::size_type len = pStr.length(); //Variable to hold the size of the word

	bool foundVowel = false; //Variable used in determin

	bool isPunctB = isPuncutation(pStr[len - 1]); //isPunct is true if punctuation is found at the end of the word
	bool isPunctF = isPuncutation(pStr[0]); //isPunct is true if punctuation is found in front of the word
	char puncMarks[2] = {' ', ' '}; //Will hold the punctuation in the word if there is one

	string::size_type counter; //Used as a counter in a for loop

	//main processing starts here

	if (isPunctB) {
		puncMarks[0] = pStr[len - 1]; //Assigns puncMark the punctuation mark if one is found in the back of the word
		//Removes one from len so that punctuation does not interfere with looping or if statements through 
		//and the punctuation can be readded at the end of the function
		len -= 1;
	}

	if (isPunctF) {
		puncMarks[1] = pStr[0]; //Assigns puncMark the punctuation mark if one is found in the front of the word
		pStr = rotate(pStr, len); //Rotates the front puncutation to the back of the word to avoid using it in the for-loop
		//Removes one from len so that punctuation does not interfere with looping or if statements through 
		//and the punctuation ccan be readded at the end of the function
		len -= 1;
	}

	if (isVowel(pStr[0])) {
		//Adds the proper pig-latin ending if a vowel is the first letter
		pStr = pStr.substr(0, len) + "-way";
	}
	else {
		pStr = pStr.substr(0, len) + "-"; //Adds '-' to the word
		pStr = rotate(pStr, len); //Rotates the word one character
		len = pStr.length(); //Resets len back to the length of the word

		foundVowel = false; //Ensures foundVowel is false before looping process

		//Rotates through the word until a vowel is found, 
		//counter is 1 to account for already checking the word once, 1 is subtracted to len to account for the '-' at the end
		for (counter = 1; counter < len - 1; counter++)
			//Checks to see if the first letter is a vowel, if so the loop will break and founVowel will be true
			if (isVowel(pStr[0])) {
				foundVowel = true;
				break;
			}
			else //If a vowel is not found the word will be rotated and checked again in the next iteration
				pStr = rotate(pStr, len);
		//Determines the proper ending for the word
		if (!foundVowel)
			pStr.substr(1, len) + "-way";
		else
			pStr = pStr + "ay";
	}
	//If the word has punctuation, it will be tacked back onto the word
	if (isPunctB)
		pStr = pStr + puncMarks[0];
	if (isPunctF)
		pStr = puncMarks[1] + pStr;
	return pStr; //Returns the word in pigLatin
}

//This function is the one that actually rotates the first char to the end
string rotate(string pStr, string::size_type len) {
	string rStr; //Temp used for rotation
	rStr = pStr.substr(1, len) + pStr[0]; //Moves the 1st letter to end - adds it to rest of the string
	return rStr;
}


//Is the character a vowel
bool isVowel(char ch) {
	switch (ch) {
	case 'A': case 'E': case 'I': case 'O': case 'U': case 'Y':
	case 'a': case 'e': case 'i': case 'o': case 'u': case 'y':
		return true;
		break;
	default:
		return false;
	}
}

//Checks to see if there is punctuation in the desired character
bool isPuncutation(char ch) {
	switch (ch) {
	case ';': case ':': case'?': case '!': case ',': case '.': case '"':
		return true;
		break;
	default:
		return false;
	}
}