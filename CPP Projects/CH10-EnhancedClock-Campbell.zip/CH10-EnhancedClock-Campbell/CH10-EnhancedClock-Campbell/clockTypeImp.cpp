//clockType implementation - contains implementation of each public class function

#include "ClockType.h"
#include <iostream>

using namespace std;

//Constructor with parameters
clockType::clockType(int hr, int min, int sec, char amOrPm) {
	//Setting private member variables, set to -1 if invalid
	if (amOrPm == 'x') { //If the time is in military time
		if (hr >= 0 && hr <= 23)
			this->hr = hr;
		else
			this->hr = -1;
	}
	else { //If time is 12 hour
		if (hr > 0 && hr <= 12)
			this->hr = hr;
		else
			this->hr = -1;
	}

	if (min >= 0 && min <= 59)
		this->min = min;
	else
		this->min = -1;
	if (sec >= 0 && sec <= 59)
		this->sec = sec;
	else
		this->sec = -1;
	this->amOrPm = amOrPm;
}

//Default constructor
clockType::clockType() {
	hr = 0;
	min = 0;
	sec = 0;
	amOrPm = 'x';
}

//Gets the time and assigns it to parameters
void clockType::getTime(int& hr, int& min, int& sec) const {
	hr = this->hr;
	min = this->min;
	sec = this->sec;
}

//set the time of the clock obj with hh mm ss
void clockType::setTime(int hr, int min, int sec, char amOrPm) {
	//Setting private member variables, set to -1 if invalid
	if (amOrPm == 'x') { //If the time is in military time
		if (hr >= 0 && hr <= 23)
			this->hr = hr;
		else
			this->hr = -1;
	}
	else { //If time is 12 hour
		if (hr > 0 && hr <= 12)
			this->hr = hr;
		else
			this->hr = -1;
	}

	if (min >= 0 && min <= 59)
		this->min = min;
	else
		this->min = -1;
	if (sec >= 0 && sec <= 59)
		this->sec = sec;
	else
		this->sec = -1;
	this->amOrPm = amOrPm;
}

//Bumps the value of hr up by one
void clockType::incrementHour() {
	hr++;
	if (hr > 23) {
		hr = 0;
		sec = 0;
		min = 0;
	}
}

//Bumps the value of min up by one
void clockType::incrementMinute() {
	//Old time 12:59:30
	min++; //New time 12:60:30
	if (min > 59) {
		min = 0; //new time 12:00:30
		incrementHour(); //Current time 13:00:30
	}
}

//Bumps the value of sec up by one
void clockType::incrementSecond() {
	sec++;
	if (sec > 59) {
		sec = 0;
		incrementMinute();
	}
}

//Prints the hh:mm:ss of the clock
void clockType::printTimeTwelve() {
	if(amOrPm == 'x')
		convMilToTwelve(hr, min, sec);
	if (hr > 9) //If hr is double digit time, just print it, otherwise add leading 0
		cout << hr << ":";
	else
		cout << "0" << hr << ":";

	if (min > 9) //If min is double digit time, just print it, otherwise add leading 0
		cout << min << ":";
	else
		cout << "0" << min << ":";

	if (sec > 9) //If sec is double digit time, just print it, otherwise add leading 0
		cout << sec;
	else
		cout << "0" << sec;
	cout << " " << amOrPm << "m";

}


// Prints the hhmm:ss am/pm of the clock
void clockType::printTimeMil() {
	if(amOrPm != 'x')
		convTwelveToMil(hr, min, sec, amOrPm);
		if (hr > 9) //If hr is double digit time, just print it, otherwise add leading 0
			cout << hr;
		else
			cout << "0" << hr;

		if (min > 9) //If min is double digit time, just print it, otherwise add leading 0
			cout << min << ":";
		else
			cout << "0" << min << ":";

		if (sec > 9) //If sec is double digit time, just print it, otherwise add leading 0
			cout << sec;
		else
			cout << "0" << sec;
}

//This function will intake a time based on the 12 hour clock system, and convert it to military and assigns the clock times to it.
void clockType::convTwelveToMil(int hr, int min, int sec, char amOrPm) {
	if (hr > 12 || hr <= 0) { //Returns if hr is not applicable to 12 hour clock
		cout << "Invalid time" << endl;
		return;
	}
	if (hr == 12 && toupper(amOrPm) == 'A'){
		hr = 0;
	}else if (toupper(amOrPm) == 'P' && hr < 12) {
		hr += 12;
	}
	setTime(hr, min, sec, 'x'); //Updates clock to given military time
}

//This function will intake a time based on the 24 hour clock system, and convert it to 12 hour.
void clockType::convMilToTwelve(int hr, int min, int sec) {
	
	if (hr >= 12) {
		if(hr > 12)
			hr -= 12;
		amOrPm = 'P';
	}
	else {
		if (hr == 0)
			hr = 12;
		amOrPm = 'A';
	}
	setTime(hr, min, sec, amOrPm); //Updates clock to given 12 hour time
}

//This function will find the difference between two clocks.
void clockType::timeDifference(int hr1, int min1, int sec1, int hr2, int min2, int sec2, char amOrPm1, char amOrPm2) {
	int difference = elapseTimeSec(hr1, min1, sec1, amOrPm1);
	cout << "The difference between the time "; 
	printTimeTwelve();
	difference = abs(difference - elapseTimeSec(hr2, min2, sec2, amOrPm2));
	cout << " and ";
	printTimeTwelve();
	cout << " is " << (difference / 60) / 60 << " Hours " << (difference / 60) % 60 << " Minutes and " << difference % 60 << " Seconds" << endl << endl;
}

//This function will intake a time based on the12 hour clock system and add 11:55:55 to it
void clockType::add115555(int hr, int min, int sec, char amOrPm) {
	const int ADDITIVE = elapseTimeSec(11, 55, 55, 'a');//Convert 11:55:55 into seconds
	const int SECONDS_IN_A_DAY = 86400; //Seconds in a day
	int newTimeInSec = ADDITIVE + elapseTimeSec(hr, min, sec, amOrPm); //Total seconds of addditive and given time
	//If the result is over a day, then it will need to be rolled over to a time on the following day
	if (newTimeInSec > SECONDS_IN_A_DAY)
		newTimeInSec -= SECONDS_IN_A_DAY;
	setTime((newTimeInSec / 60) / 60, (newTimeInSec / 60) % 60, newTimeInSec % 60);//Sets the time in military time
}


//Check to see if time on bothe clocks is equal
bool clockType::equalTime(const clockType& otherClock) const {
	return (hr == otherClock.hr && min == otherClock.min && sec == otherClock.sec);
}

//Function to validate input values
bool clockType::isValid(int hr, int min, int sec, char amOrPm) const {
	if(!(toupper(amOrPm) == 'P' || toupper(amOrPm) == 'A' || toupper(amOrPm) == 'X'))
		return false;
	if (amOrPm == 'x') { //If the time is in military time
		if (!(hr >= 0 && hr <= 23))
			return false;
	}
	else { //If time is 12 hour
		if (!(hr > 0 && hr <= 12))
			return false;
	}

	if (!(min >= 0 && min <= 59))
		return false;
	if (!(sec >= 0 && sec <= 59))
		return false;
}

//This function will calulate the time in seconds based of a 12 hour time input
int clockType::elapseTimeSec(int hr, int min, int sec, char amOrPm) {
	convTwelveToMil(hr, min, sec, amOrPm);
	return (this->hr * 60 + this->min)*60 + this->sec;
}

//This function will return the remaining time of day in seconds
int clockType::remainingTimeInSec(int hr, int min, int sec, char amOrPm) {
	return 86400 - elapseTimeSec(hr, min, sec, amOrPm);
}
