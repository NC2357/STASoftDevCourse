//#pragma once
//REMEMBER TO ADD PRECONDITIONS AND POSTCONDITIONS
//clockType definition
//Class that acts like a clock.
class clockType {
public:
	void getTime(int&, int&, int&) const; //Get the time
	//Function to return the time
	//PostCondition: hr = this->hr, min = this->min, sec = this->sec
	void setTime(int, int, int, char amOrPm = 'x'); //set the time of the clock obj with hh mm ss

	//Function to set the time
	//The time is set according to the parameters
	//Precondition - three integer parameter(hours, minutes, seconds)
	//Postcondition: this->hr = hr, this->min = min, this->sec = sec
	//The function chacks to ensure valid values(0<=ht<=23), (0<=min<=59), (0<=sec=59)
	//If not valid, set value to -1

	void incrementHour(); //Bumps the value of hr up by one
	//Function to increase the current time by 1 hour
	//Postcondition: The time is incremented by 1 hour
	//If the hour before increment is 23, resets the time to 00:00:00

	void incrementMinute(); //Bumps the value of min up by one
	//Function to increase the current time by 1 minute
	//Postcondition: The time is incremented by 1 minute
	//If the min before increment is 59, resets to zeros and bumps hour by one

	void incrementSecond(); //Bumps the value of sec up by one
	//Function to increase the current time by 1 second
	//Postcondition: The time is incremented by 1 second
	//If the sec before increment is 59, resets to zeros and bumps min by one

	void printTimeTwelve(); //Prints the hh mm ss of the clock
	//Function to print the time
	//Postcondition: The time is printed in HH:MM:SS format

	void printTimeMil(); //Prints the military time of the clock
	//Function to print the time
	//Postcondition: The time is printed in HHMM:SS format

	void convTwelveToMil(int, int, int, char);
	//This function will intake a time based on the 12 hour clock system, and convert it to military and assigns the clock times to it.
	//PreCondition: three integer parameter(hours, minutes, seconds) and a char used to determine AM or PM
	//Postconditon: The clock object's time is replaced by the mmilitary time generated

	void convMilToTwelve(int, int, int);
	//This function will intake a time based on the 24 hour clock system, and convert it to 12 hour.
	//PreCondition: Three integer parameters (hr, min, sec) and a char by reference to signify am or pm
	//Postconditon: Replaces clock time with the given 12 hour time

	void timeDifference(int, int, int, int, int, int, char, char);
	//This function will find the difference between two clocks.
	//PreCondition: Three integer parameters (hr, min, sec) and a char by reference to signify am or pm for two clocks
	//Postconditon: Outputs the difference between them

	void add115555(int, int, int, char);
	//This function will intake a time based on the12 hour clock system and add 11:55:55 to it
	//PreCondition: Three integer parameters (hr, min, sec) and a char by reference to signify am or pm
	//Postconditon: Replaces clock time with the given time + 11:55:55

	bool equalTime(const clockType&) const; //Check to see if time on both clocks is equal
	//Function to see if two clocks are equal
	//Postcondition: returns true if hr == otherClock.hr, min == otherClock.min, sec == otherClock.sec
	//otherwise returns false

	bool isValid(int, int, int, char = 'x') const;
	//Function to validate input values
	//Pre: Intake three integers (hr, min, sec) and char for am,pm, or military
	//Post: Return true if input is valid, false otherwise

	int elapseTimeSec(int, int, int, char);
	//This function will calulate the time in seconds based of a 12 hour time input
	//Precondition - three integer parameter(hours, minutes, seconds) and char to determine am or pm
	//Postcondition: this->hr = hr, this->min = min, this->sec = sec

	int remainingTimeInSec(int, int, int, char);
	//This function will return the remaining time of day in seconds
	//Precondition - three integer parameter(hours, minutes, seconds) and char to determine am or pm
	//Postcondition: this->hr = hr, this->min = min, this->sec = sec

	clockType(int, int, int, char = 'x'); //Parameter constructor
	//Function to setup the clock object
	//Precondition: three integer parameter(hours, minutes, seconds) and char to determine am/pm or military
	//Postcondition: this->hr = hr, this->min = min, this->sec = sec
	//The function chacks to ensure valid values(0<=ht<=23), (0<=min<=59), (0<=sec=59)
	//If not valid, set value to zero

	clockType(); //Default constructor
	//Function to setup the clock object
	//Postcondition: sets hr = 0, min = 0, and sec = 0

private:
	int hr, min, sec; //Holds each time. hr(0-23), min (0-59), sec (0-59)
	char amOrPm; //Holds whether the clock is am pm or military
};

