//Nolan Campbell 16112020
//Chapter 10 Enhanced Clock
//This program will use a clockType class, then create two clock instances
//myClock and yourClock, After that we will write the class functions to set
//time and get the time, the class will also get the time in seconds, get remaining time in a day in seconds
//Difference between two clock times, convert 12 hour clock to 24 hour clock and vice versa, and add 11:55:55 to a 12 hour clock and output military

#include "ClockType.h"
#include<iostream>

using namespace std;

int main() {

	//Declare two identifiers of type clockType
	clockType myClock;
	clockType yourClock;

	int hr, min, sec, hr2, min2, sec2; //local variables for main
	char amOrPm, amOrPm2; //Used to determine if time is am or pm

	cout << "This clock will prompt for times for a clock, and do various tasks with it." << endl << endl;

	//Testing elapseTimeSec method
	cout << "This function will return the number of seconds that have elasped so far." << endl;
	cout << "Please enter a time in HH MM SS format within the twelve hour time frame: ";
	cin >> hr >> min >> sec;
	cout << "Please indicate AM with(A) or PM with(P): ";
	cin >> amOrPm;
	cout << endl;

	if (myClock.isValid(hr, min, sec, amOrPm)) {
		int elapseSec = myClock.elapseTimeSec(hr, min, sec, amOrPm);
		cout << "Based on the given time of ";
		myClock.printTimeTwelve();
		cout << " the total seconds is: " << elapseSec << endl << endl;
	}
	else {
		cout << endl << endl << "Invalid input, Advancing to next function" << endl << endl;
	}

	//Testing remainingTimeSec method
	cout << "This method will return the remaining number of seconds in a day." << endl;
	cout << "Please enter a time in HH MM SS format within the twelve hour time frame: ";
	cin >> hr >> min >> sec;
	cout << "Please indicate AM with(A) or PM with(P): ";
	cin >> amOrPm;
	cout << endl;

	if (myClock.isValid(hr, min, sec, amOrPm)) {
		int remainSec = myClock.remainingTimeInSec(hr, min, sec, amOrPm);
		cout << "Based on the given time of ";
		myClock.printTimeTwelve();
		cout << " the total remaining seconds in the day is is: " << remainSec << endl << endl;
	} else {
		cout << endl << endl << "Invalid input, Advancing to next function" << endl << endl;
	}

	//Testing convTwelveToMil method
	cout << "This method will convert twelve hour time to military time" << endl;
	cout << "Please enter a time in HH MM SS format within the twelve hour time frame: ";
	cin >> hr >> min >> sec;
	cout << "Please indicate AM with(A) or PM with(P): ";
	cin >> amOrPm;
	cout << endl;

	if (myClock.isValid(hr, min, sec, amOrPm)) {
		myClock.setTime(hr, min, sec, amOrPm);

		cout << "Based on the given time of ";
		myClock.printTimeTwelve();
		cout << " the time of it in military time is ";
		myClock.printTimeMil();
		cout << endl << endl;
	} else {
		cout << endl << endl << "Invalid input, Advancing to next function" << endl << endl;
	}

	//Testing convMilToTwelve method
	cout << "This function will convert military time to twelve hour time." << endl;
	cout << "Please enter a time in HH MM SS format within the bounds of military time(hours between 0 and 23): ";
	cin >> hr >> min >> sec;
	cout << endl;

	if (myClock.isValid(hr, min, sec)) {
		myClock.setTime(hr, min, sec);

		cout << "Based on the given time of ";
		myClock.printTimeMil();
		cout << " the time of it in twelve hour time is ";
		myClock.printTimeTwelve();
		cout << endl << endl;
	} else {
		cout << endl << endl << "Invalid input, Advancing to next function" << endl << endl;
	}

	//Testing difference between two times
	cout << "This method will find the difference between two clocks" << endl;
	cout << "Please enter a time in HH MM SS format within the twelve hour time frame for clock 1: ";
	cin >> hr >> min >> sec;
	cout << "Please indicate AM with(A) or PM with(P): ";
	cin >> amOrPm;

	cout << "Please enter a time in HH MM SS format within the twelve hour time frame for clock 2: ";
	cin >> hr2 >> min2 >> sec2;
	cout << "Please indicate AM with(A) or PM with(P): ";
	cin >> amOrPm2;
	cout << endl; 

	if (myClock.isValid(hr, min, sec, amOrPm) && myClock.isValid(hr2, min2, sec2, amOrPm2)) {
		myClock.timeDifference(hr, min, sec, hr2, min2, sec2, amOrPm, amOrPm2);
	} else {
		cout << endl << endl << "Invalid input, Advancing to next function" << endl << endl;
	}

	//Testing adding 11:55:55 to a time
	cout << "This method will add 11:55:55 to the given time." << endl;
	cout << "Please enter a time in HH MM SS format within the twelve hour time frame: ";
	cin >> hr >> min >> sec;
	cout << "Please indicate AM with(A) or PM with(P): ";
	cin >> amOrPm;
	cout << endl;

	if (myClock.isValid(hr, min, sec, amOrPm)) {
		myClock.add115555(hr, min, sec, amOrPm);
		cout << "The time after adding 11:55:55 is ";
		myClock.printTimeMil();
	} else{
		cout << endl << endl << "Invalid input, Advancing to next function" << endl << endl;
	}

	cout << endl << endl;
	system("PAUSE");
	return 0;
}