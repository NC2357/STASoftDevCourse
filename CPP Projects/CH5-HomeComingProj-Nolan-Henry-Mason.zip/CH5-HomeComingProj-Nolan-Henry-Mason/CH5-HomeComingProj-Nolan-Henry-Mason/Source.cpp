// Mason, Henry, Nolan 10/05/20 
// This program will help manage all the info of Homecoming in Murphyville. It will print out info about the band management,
// the scoreboard for the Homecoming football game, and the music for the Homecoming Dance.

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

void paradeModule() {
	//Nolan Campbell 05102020
	//Home Coming project - Parade module
	//This module will prompt the band instructor for number of members in each section (Percussion, winds, brass)
	//It will then prompt for the width of the formation and print out the formation
	//It will then reprint the band formation with half the width

	//////declaration
	int numPerc, numBrass, numWinds, bandWidth, totalMem, numRows, memCheck;
	const string bandLabel = "Murphy MudMule Marching Band Parade Formation";
	bool isValid = false;

	//////data intake

	cout << "Hello Dr. Music, please answer the following question to determine your band formation. " << endl << endl;

	while (!isValid) {
		cout << "Please enter the number of percussionists in the band(Positive): ";
		cin >> numPerc;
		cout << endl;

		cout << "Please enter the number of brass in the band(Positive): ";
		cin >> numBrass;
		cout << endl;

		cout << "Please enter the number of winds in the band(Positive): ";
		cin >> numWinds;
		cout << endl;

		cout << "Please enter the row width for the band(More than 0 but no more than twenty): ";
		cin >> bandWidth;
		cout << endl;

		if (numPerc >= 0 && numBrass >= 0 && numWinds >= 0 && bandWidth > 0 && bandWidth <= 20) {
			isValid = true;
		}
		else {
			cout << "Invalide data entered, please reanswer the questions." << endl << endl;
		}
	}

	//Calculation
	totalMem = numPerc + numBrass + numWinds; //finds total number of band members and places it in totalMem

	///////Pre mime float crash

	memCheck = totalMem; //memCheck will be used to break the loop when the band runs out of members

	numRows = totalMem / bandWidth; //Determines the number of rows for the band

	//In the case that there are extra members who will not form a full row are given a row
	numRows += (totalMem % bandWidth > 0) ? 1 : 0;

	//Output

	//Band label print
	cout << setfill('+') << setw(bandLabel.length() + 4.0) << "" << endl;
	cout << "+ " << bandLabel << " +" << endl;
	cout << setfill('+') << setw(bandLabel.length() + 4.0) << "" << endl << endl << setfill(' ');

	//Band formation print
	for (int i = 0; i < numRows; i++) {
		cout << setw(10); //Used to space out the prints from the edge of the screen
		for (int j = 0; j < bandWidth; j++) {
			cout << "| M ";
			//Following deincrement and if statement used to ensure that there are still band members left to print
			memCheck--;
			if (memCheck <= 0) {
				break;
			}
		}
		cout << "|" << endl;
		if (memCheck <= 0) {
			break;
		}
	}
	cout << endl << endl;

	//////Post mime float crash

	cout << "The mime float has broken down, the band width must be split in half." << endl << endl;

	//Calculation
	memCheck = totalMem; //memCheck will be used to break the loop when the band runs out of members

	bandWidth /= 2; //Divides band width by two to account for the narrowing required to pass the mime float

	numRows = totalMem / bandWidth; //Determines the number of rows for the band

	//In the case that there are extra members who will not form a full row are given a row
	numRows += (totalMem % bandWidth > 0) ? 1 : 0;

	//output

	//Band label print
	cout << setfill('+') << setw(bandLabel.length() + 4.0) << "" << endl;
	cout << "+ " << bandLabel << " +" << endl;
	cout << setfill('+') << setw(bandLabel.length() + 4.0) << "" << endl << endl << setfill(' ');

	//Band formation print
	for (int i = 0; i < numRows; i++) {
		cout << setw(10); //Used to space out the prints from the edge of the screen
		for (int j = 0; j < bandWidth; j++) {
			cout << "| m ";
			//Following deincrement and if statement used to ensure that there are still band members left to print
			memCheck--;
			if (memCheck <= 0) {
				break;
			}
		}
		cout << "|" << endl;
		if (memCheck <= 0) {
			break;
		}
	}
}

void danceMusicModule() {
	///////////////////////////////////// ADD #include<fstream> FOR THIS TO WORK! \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


	// Henry - 10/5/20 & 10/6/20
		// 10/5: Initial Pseudocode & framework of program, variables declared, and file initialized and created
		// 10/6: Reconfiguration & implementation of embedded statements & output.

	// Dance music module that reads the song and song length from the music file
	// Subtracts the time while there is time left to play music, if else, tells a joke and breaks the loop.
	// If there is not enough time to play a song, write a joke into the output.

	string Playing = "";		// This is the song name, which is a string.
	double Length, time = 60;	// Length of the song which is taken from the file, and the time length of the night.
	ifstream Songs;				// Declaring the input file as Songs.

	Songs.open("MMMABGroovySongs.txt");


	while (time > 0)
	{

		Songs >> Playing >> Length; // Taking input from the file. We do it like this because both variables are on the same line.

		if ((time - Length) < 0 || Songs.eof())	// Detecting if there is enough time left to play a full song.
		{

			if ((time - Length) < 0)	// Since we still have time left, and are not EOF, we tell a joke.
			{
				cout << endl << "Looks like we don't have time for another song tonight, Here's a joke instead.";

				cout << endl << "Have you heard how popular the cemetary is?";
				cout << endl << "People are just dying to get in!" << endl;
			}

			else if (Songs.eof())
			{
				cout << endl << "Well folks, we've gone through the entire playlist tonight!";
				cout << endl << "We still have " << time << " minutes left, so here's a joke.";

				cout << endl << "What does a house always wear to a party?";
				cout << endl << "Adress. Now that's a classic!" << endl;

			}

			cout << endl << "Thank you all for being the best MudMoles ever!" << endl;
			cout << "Everyone give a huge thanks to the MMMAB for tonights music!" << endl;

			break;	// Breaking the loop since we ran out of time and told our joke.
		}

		else if (!Songs.eof())		// Since we didnt meet any criteria to stop, we continue the loop, and keep playing songs.
		{
			time -= Length;

			cout << Playing << " Is now playing, it is " << Length << " minutes long." << endl;	// Outputting the song name, how long it is.
			cout << "We have " << time << " minutes left tonight." << endl;						// Outputting how long we have for the rest of the night.

		}
	}


	Songs.close();
}

void scoreBoardModule() {
	//Mason scoreboard module
	// SCOREBOARD

	int homeTD = 0, homeFG = 0, visitorTD = 0, visitorFG = 0, homeTtl = 0, visitorTtl = 0;
	int quarter;



	for (quarter = 1; quarter <= 4; quarter++) {

		cout << "Please enter the number of Touchdowns for the home team: " << endl;
		cin >> homeTD;
		cout << endl;

		cout << "Please enter the number of Touchdowns for the visiting team: " << endl;
		cin >> visitorTD;
		cout << endl;

		cout << "Please enter the number of field goals for the home team: " << endl;
		cin >> homeFG;
		cout << endl;

		cout << "Please enter the number of field goals for the visitor team: " << endl;
		cin >> visitorFG;
		cout << endl;

		cout << endl;
		cout << endl;
		homeTtl = homeTtl + (homeTD * 7) + (homeFG * 3);
		visitorTtl = visitorTtl + (visitorTD * 7) + (visitorFG * 3);

		cout << "*" << setw(60) << setfill('*') << "*" << endl;
		cout << "*" << setw(29) << setfill(' ') << left << "   HOME TEAM" << setw(29) << right << "VISITOR TEAM   " << " *" << endl;
		cout << "*   " << setw(26) << left << homeTtl << setw(26) << right << visitorTtl << "    *" << endl;
		cout << "*   " << setw(26) << right << "Quarter: " << quarter << setw(26) << right << "" << "   *" << endl;
		cout << "*" << setw(60) << setfill('*') << "*" << endl;

		while (quarter >= 4) {
			if (homeTtl == visitorTtl) {
				cout << "Please enter the number of Touchdowns for the home team: " << endl;
				cin >> homeTD;
				cout << endl;

				cout << "Please enter the number of Touchdowns for the visiting team: " << endl;
				cin >> visitorTD;
				cout << endl;

				cout << "Please enter the number of field goals for the home team: " << endl;
				cin >> homeFG;
				cout << endl;

				cout << "Please enter the number of field goals for the visitor team: " << endl;
				cin >> visitorFG;
				cout << endl;

				cout << endl;
				cout << endl;
				homeTtl = homeTtl + (homeTD * 7) + (homeFG * 3);
				visitorTtl = visitorTtl + (visitorTD * 7) + (visitorFG * 3);

				cout << "*" << setw(60) << setfill('*') << "*" << endl;
				cout << "*" << setw(29) << setfill(' ') << left << "   HOME TEAM" << setw(29) << right << "VISITOR TEAM   " << "*" << endl;
				cout << "*   " << setw(26) << left << homeTtl << setw(26) << right << visitorTtl << "   *" << endl;
				cout << "*   " << setw(26) << right << "Quarter: OT " << setw(26) << right << " " << "   *" << endl;
				cout << "*" << setw(60) << setfill('*') << "*" << endl;
				quarter++;
			}
			else {
				if (homeTtl > visitorTtl) {
					cout << "Congratulations Home team!!";

				}
				if (homeTtl < visitorTtl) {
					cout << "Congratulations Visiting team!!";
				}


				break;
			}
		}
	}
}

int main() {

	const string menuLabel = "Murphy High MudMule Homecoming menu";
	bool stopMenu = false;
	int choice;

	//////menu
	cout << setfill('+') << setw(menuLabel.length() + 4.0) << "" << endl;
	cout << "+ " << menuLabel << " +" << endl;
	cout << setfill('+') << setw(menuLabel.length() + 4.0) << "" << endl << setfill(' ');

	while (!stopMenu) {

		//Let's user decide which module they want to run
		cout << endl << "Enter the number according to which module you want to run or -1 to exit" << endl << endl;
		cout << "Parade Module = 1" << endl;
		cout << "Dance Music Module = 2" << endl;
		cout << "Scoreboard Module = 3" << endl;
		cin >> choice;
		cout << endl;

		switch (choice) {
		case 1:
			cout << "This module will simulate the band parade formation" << endl << endl;
			paradeModule();
			break;
		case 2:
			cout << "This module will simulate the Homecoming playlist" << endl << endl;
			danceMusicModule();
			break;
		case 3:
			cout << "This module will simulate the Homecoming football scoreboard" << endl << endl;
			scoreBoardModule();
			break;
		case -1:
			cout << "Goodbye" << endl;
			stopMenu = true;
			break;
		default:
			cout << "Invalid input" << endl;
			break;
		}
	}


	system("PAUSE");
	return 0;
}